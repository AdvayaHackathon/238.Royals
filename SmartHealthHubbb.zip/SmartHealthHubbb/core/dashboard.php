<?php
require_once "../includes/auth.php"; // session check
require_once "../config/db.php";

// Check if a session is already active before starting a new one
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Dummy motivational quotes
$thoughts = [
    "Stay strong, stay hopeful 💪",
    "Your health is your greatest wealth 🩺",
    "Every step counts. Keep going!",
    "Small changes make big impacts 💚",
    "You deserve care and confidence 🌟"
];

$quote = $thoughts[array_rand($thoughts)];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - Smart HealthHub</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary: #6a4c93;
            --primary-dark: #4a2c7a;
            --primary-light: #8f6cb3;
            --secondary: #3f37c9;
            --accent: #4cc9f0;
            --jelly-blue: #4cc9f0;
            --jelly-purple: #9b5de5;
            --jelly-pink: #f15bb5;
            --success: #4ad66d;
            --error: #f72585;
            --warning: #f8961e;
            --light: #f8f9fa;
            --dark: #212529;
            --gray: #6c757d;
            --light-gray: #e9ecef;
            --shadow-sm: 0 1px 3px rgba(0, 0, 0, 0.1);
            --shadow-md: 0 4px 6px rgba(0, 0, 0, 0.15);
            --shadow-lg: 0 10px 25px rgba(0, 0, 0, 0.2);
            --transition: all 0.3s cubic-bezier(0.25, 0.8, 0.25, 1);
            --border-radius: 16px;
            --glass-effect: rgba(255, 255, 255, 0.2);
            --nav-height: 80px;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Poppins', sans-serif;
            background: linear-gradient(135deg, #0f0c29 0%, #302b63 50%, #24243e 100%);
            color: white;
            min-height: 100vh;
            display: flex;
            flex-direction: column;
            line-height: 1.6;
            position: relative;
            overflow-x: hidden;
        }

        /* Jellyfish animation background */
        .jellyfish-bg {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            z-index: -1;
            overflow: hidden;
        }

        .jellyfish {
            position: absolute;
            opacity: 0.15;
            filter: blur(30px);
            animation: float 15s infinite ease-in-out;
        }

        .jellyfish:nth-child(1) {
            width: 300px;
            height: 300px;
            background: radial-gradient(circle, var(--jelly-blue), transparent 70%);
            top: 20%;
            left: 10%;
            animation-delay: 0s;
        }

        .jellyfish:nth-child(2) {
            width: 400px;
            height: 400px;
            background: radial-gradient(circle, var(--jelly-purple), transparent 70%);
            top: 60%;
            left: 60%;
            animation-delay: 2s;
        }

        .jellyfish:nth-child(3) {
            width: 250px;
            height: 250px;
            background: radial-gradient(circle, var(--jelly-pink), transparent 70%);
            top: 30%;
            left: 80%;
            animation-delay: 4s;
        }

        .jellyfish:nth-child(4) {
            width: 350px;
            height: 350px;
            background: radial-gradient(circle, var(--jelly-blue), transparent 70%);
            top: 70%;
            left: 20%;
            animation-delay: 6s;
        }

        @keyframes float {
            0%, 100% {
                transform: translateY(0) translateX(0);
            }
            25% {
                transform: translateY(-50px) translateX(20px);
            }
            50% {
                transform: translateY(20px) translateX(50px);
            }
            75% {
                transform: translateY(50px) translateX(-20px);
            }
        }

        /* Navigation */
        .navbar {
            background: rgba(15, 12, 41, 0.8);
            backdrop-filter: blur(10px);
            -webkit-backdrop-filter: blur(10px);
            height: var(--nav-height);
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 0 40px;
            position: fixed;
            width: 100%;
            top: 0;
            z-index: 1000;
            box-shadow: 0 2px 20px rgba(0, 0, 0, 0.3);
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        }

        .logo {
            display: flex;
            align-items: center;
            gap: 10px;
            font-size: 1.5rem;
            font-weight: 700;
            color: white;
            text-decoration: none;
        }

        .logo i {
            color: var(--jelly-blue);
        }

        .nav-links {
            display: flex;
            gap: 30px;
        }

        .nav-links a {
            color: white;
            text-decoration: none;
            font-weight: 500;
            position: relative;
            padding: 5px 0;
            transition: var(--transition);
        }

        .nav-links a::after {
            content: '';
            position: absolute;
            bottom: 0;
            left: 0;
            width: 0;
            height: 2px;
            background: linear-gradient(to right, var(--jelly-blue), var(--jelly-purple));
            transition: var(--transition);
        }

        .nav-links a:hover::after {
            width: 100%;
        }

        .nav-links a:hover {
            color: var(--jelly-blue);
        }

        .user-menu {
            display: flex;
            align-items: center;
            gap: 20px;
        }

        .user-menu .profile {
            display: flex;
            align-items: center;
            gap: 10px;
            cursor: pointer;
            position: relative;
        }

        .user-menu .profile img {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            object-fit: cover;
            border: 2px solid var(--jelly-blue);
        }

        .user-menu .profile-name {
            font-weight: 500;
        }

        .dropdown-menu {
            position: absolute;
            top: 60px;
            right: 0;
            background: rgba(15, 12, 41, 0.95);
            border-radius: var(--border-radius);
            padding: 15px 0;
            min-width: 200px;
            box-shadow: var(--shadow-lg);
            opacity: 0;
            visibility: hidden;
            transform: translateY(10px);
            transition: var(--transition);
            z-index: 1001;
            border: 1px solid rgba(255, 255, 255, 0.1);
        }

        .profile:hover .dropdown-menu {
            opacity: 1;
            visibility: visible;
            transform: translateY(0);
        }

        .dropdown-menu a {
            display: block;
            padding: 10px 20px;
            color: white;
            text-decoration: none;
            transition: var(--transition);
        }

        .dropdown-menu a:hover {
            background: rgba(255, 255, 255, 0.1);
            color: var(--jelly-blue);
        }

        .dropdown-menu a i {
            margin-right: 10px;
            width: 20px;
            text-align: center;
        }

        /* Main content */
        .dashboard-container {
            max-width: 1200px;
            margin: calc(var(--nav-height) + 30px) auto 30px;
            padding: 30px;
            flex: 1;
        }

        /* Welcome section */
        .welcome-section {
            background: rgba(255, 255, 255, 0.05);
            backdrop-filter: blur(10px);
            -webkit-backdrop-filter: blur(10px);
            border-radius: var(--border-radius);
            padding: 30px;
            margin-bottom: 30px;
            border: 1px solid rgba(255, 255, 255, 0.1);
            box-shadow: var(--shadow-md);
            position: relative;
            overflow: hidden;
        }

        .welcome-section::before {
            content: '';
            position: absolute;
            top: -50%;
            left: -50%;
            width: 200%;
            height: 200%;
            background: radial-gradient(circle, rgba(106, 76, 147, 0.1) 0%, transparent 70%);
            animation: rotate 20s linear infinite;
            z-index: -1;
        }

        @keyframes rotate {
            from {
                transform: rotate(0deg);
            }
            to {
                transform: rotate(360deg);
            }
        }

        h2 {
            color: white;
            margin-bottom: 10px;
            font-weight: 700;
            font-size: 2.2rem;
            position: relative;
            display: inline-block;
        }

        h2 span {
            background: linear-gradient(to right, var(--jelly-blue), var(--jelly-purple));
            -webkit-background-clip: text;
            background-clip: text;
            color: transparent;
        }

        .welcome-section p {
            color: rgba(255, 255, 255, 0.8);
            margin-bottom: 5px;
        }

        /* Thought box */
        .thought-box {
            background: rgba(255, 255, 255, 0.05);
            backdrop-filter: blur(10px);
            -webkit-backdrop-filter: blur(10px);
            border-radius: var(--border-radius);
            padding: 30px;
            margin: 30px 0;
            box-shadow: var(--shadow-md);
            border-left: 4px solid var(--jelly-blue);
            transition: var(--transition);
            border: 1px solid rgba(255, 255, 255, 0.1);
            position: relative;
            overflow: hidden;
        }

        .thought-box::after {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: linear-gradient(135deg, rgba(76, 201, 240, 0.05) 0%, rgba(155, 93, 229, 0.05) 100%);
            z-index: -1;
        }

        .thought-box:hover {
            transform: translateY(-5px);
            box-shadow: var(--shadow-lg);
            border-left: 4px solid var(--jelly-purple);
        }

        .thought-box h3 {
            color: var(--jelly-blue);
            margin-bottom: 15px;
            font-weight: 600;
            font-size: 1.4rem;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .thought-box p {
            font-size: 1.1rem;
            color: rgba(255, 255, 255, 0.9);
            line-height: 1.8;
        }

        /* Quick links */
        .quick-links {
            background: rgba(255, 255, 255, 0.05);
            backdrop-filter: blur(10px);
            -webkit-backdrop-filter: blur(10px);
            border-radius: var(--border-radius);
            padding: 30px;
            margin: 30px 0;
            box-shadow: var(--shadow-md);
            transition: var(--transition);
            border: 1px solid rgba(255, 255, 255, 0.1);
        }

        .quick-links:hover {
            transform: translateY(-5px);
            box-shadow: var(--shadow-lg);
        }

        .quick-links h3 {
            color: var(--jelly-blue);
            margin-bottom: 20px;
            font-weight: 600;
            font-size: 1.4rem;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .quick-links-container {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 20px;
        }

        .quick-links-section {
            background: rgba(106, 76, 147, 0.1);
            border-radius: var(--border-radius);
            padding: 20px;
            border: 1px solid rgba(255, 255, 255, 0.1);
        }

        .quick-links-section h4 {
            color: var(--jelly-blue);
            margin-bottom: 15px;
            font-size: 1.2rem;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .quick-links-section ul {
            list-style: none;
            display: grid;
            grid-template-columns: 1fr;
            gap: 15px;
        }

        .quick-links-section li a {
            display: flex;
            align-items: center;
            gap: 15px;
            padding: 15px;
            background: rgba(106, 76, 147, 0.1);
            border-radius: var(--border-radius);
            color: white;
            text-decoration: none;
            transition: var(--transition);
            font-weight: 500;
            border: 1px solid rgba(255, 255, 255, 0.1);
        }

        .quick-links-section li a:hover {
            background: rgba(106, 76, 147, 0.3);
            transform: translateX(10px);
            border-color: var(--jelly-blue);
        }

        .quick-links-section li a i {
            font-size: 1.2rem;
            color: var(--jelly-blue);
            width: 30px;
            height: 30px;
            display: flex;
            align-items: center;
            justify-content: center;
            background: rgba(76, 201, 240, 0.1);
            border-radius: 8px;
            padding: 5px;
        }

        /* Top section layout */
        .top-section {
            display: grid;
            grid-template-columns: 2fr 1fr;
            gap: 30px;
        }

        /* Footer */
        .footer {
            background: rgba(15, 12, 41, 0.8);
            backdrop-filter: blur(10px);
            -webkit-backdrop-filter: blur(10px);
            padding: 20px 0;
            text-align: center;
            color: rgba(255, 255, 255, 0.7);
            font-size: 0.9rem;
            border-top: 1px solid rgba(255, 255, 255, 0.1);
        }

        /* Animations */
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }

        .welcome-section, .thought-box, .quick-links {
            animation: fadeIn 0.8s ease-out;
        }

        /* Responsive */
        @media (max-width: 992px) {
            .navbar {
                padding: 0 20px;
            }
            
            .nav-links {
                gap: 15px;
            }
            
            .dashboard-container {
                padding: 20px;
            }
        }

        @media (max-width: 768px) {
            .navbar {
                flex-direction: column;
                height: auto;
                padding: 15px;
            }
            
            .nav-links {
                margin: 15px 0;
                flex-wrap: wrap;
                justify-content: center;
            }
            
            .user-menu {
                margin-top: 15px;
            }
            
            .quick-links-container {
                grid-template-columns: 1fr;
            }
            
            .top-section {
                grid-template-columns: 1fr;
            }
            
            .dashboard-container {
                margin-top: calc(var(--nav-height) + 80px);
            }
        }

        @media (max-width: 576px) {
            .welcome-section, .thought-box, .quick-links {
                padding: 20px;
            }
            
            h2 {
                font-size: 1.8rem;
            }
        }
    </style>
</head>
<body>
    <!-- Jellyfish background elements -->
    <div class="jellyfish-bg">
        <div class="jellyfish"></div>
        <div class="jellyfish"></div>
        <div class="jellyfish"></div>
        <div class="jellyfish"></div>
    </div>

    <!-- Navigation -->
    <nav class="navbar">
        <a href="#" class="logo">
            <i class="fas fa-heartbeat"></i>
            <span>Smart HealthHub</span>
        </a>
        
        <div class="nav-links">
            <a href="dashboard.php"><i class="fas fa-home"></i> Dashboard</a>
            <a href="appointments.php"><i class="fas fa-calendar-alt"></i> Appointments</a>
            <a href="feedback.php"><i class="fas fa-comment-alt"></i> Feedback</a>
            <a href="settings.php"><i class="fas fa-cog"></i> Settings</a>
        </div>
        
        <div class="user-menu">
            <div class="profile">
                <img src="../assets/images/default-profile.jpg" alt="Profile">
                <span class="profile-name"><?= htmlspecialchars($_SESSION['user_name']) ?></span>
                
                <div class="dropdown-menu">
                    <a href="profile.php"><i class="fas fa-user-circle"></i> Profile</a>
                    <a href="orders.php"><i class="fas fa-history"></i> Order History</a>
                    <a href="../auth/logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a>
                </div>
            </div>
        </div>
    </nav>

    <div class="dashboard-container">
        <div class="top-section">
            <div class="welcome-section">
                <h2>Welcome, <span><?= htmlspecialchars($_SESSION['user_name']) ?></span> 👋</h2>
                <p>Your health journey starts here. We're glad to have you back!</p>
            </div>

            <div class="thought-box">
                <h3><i class="fas fa-quote-left"></i> Thought of the Day</h3>
                <p><?= $quote ?></p>
            </div>
        </div>

        <div class="quick-links">
            <h3><i class="fas fa-rocket"></i> Quick Access</h3>
            <div class="quick-links-container">
                <div class="quick-links-section">
                    <h4><i class="fas fa-user-md"></i> Doctor Services</h4>
                    <ul>
                        <li><a href="appointments.php"><i class="fas fa-calendar-check"></i> Book Appointment</a></li>
                        <li><a href="find-doctors.php"><i class="fas fa-search"></i> Find Doctors</a></li>
                        <li><a href="chatbot_page.php"><i class="fas fa-robot"></i> AI Doctor Chat</a></li>
                    </ul>
                </div>
                
                <div class="quick-links-section">
                    <h4><i class="fas fa-pills"></i> Medicines & Services</h4>
                    <ul>
                        <li><a href="e-medical.php"><i class="fas fa-medkit"></i> e-Medical Store</a></li>
                        <li><a href="prescriptions.php"><i class="fas fa-file-prescription"></i> My Prescriptions</a></li>
                        <li><a href="orders.php"><i class="fas fa-history"></i> Order History</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>

    <footer class="footer">
        <p>&copy; <?= date('Y') ?> Smart HealthHub. All rights reserved.</p>
    </footer>
</body>
</html>