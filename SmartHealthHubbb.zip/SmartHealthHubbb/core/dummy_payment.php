<?php
require_once "../includes/auth.php";
require_once "../config/db.php";

if (!isset($_SESSION['checkout_total'])) {
    header("Location: cart.php");
    exit();
}

$total = $_SESSION['checkout_total'];
$userId = $_SESSION['user_id'];

// Process payment
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['pay'])) {
    try {
        $conn->beginTransaction();
        
        // Create order
        $stmt = $conn->prepare("INSERT INTO orders (user_id, total_amount) VALUES (?, ?)");
        $stmt->execute([$userId, $total]);
        $orderId = $conn->lastInsertId();
        
        // Move cart items to order items
        $stmt = $conn->prepare("
            INSERT INTO order_items (order_id, medicine_id, quantity, price)
            SELECT ?, c.medicine_id, c.quantity, m.price 
            FROM cart c JOIN medicines m ON c.medicine_id = m.id 
            WHERE c.user_id = ?
        ");
        $stmt->execute([$orderId, $userId]);
        
        // Update medicine stock
        $stmt = $conn->prepare("
            UPDATE medicines m
            JOIN cart c ON m.id = c.medicine_id
            SET m.stock = m.stock - c.quantity
            WHERE c.user_id = ?
        ");
        $stmt->execute([$userId]);
        
        // Clear cart
        $stmt = $conn->prepare("DELETE FROM cart WHERE user_id = ?");
        $stmt->execute([$userId]);
        
        $conn->commit();
        
        unset($_SESSION['checkout_total']);
        $_SESSION['order_success'] = true;
        header("Location: orders.php");
        exit();
    } catch (Exception $e) {
        $conn->rollBack();
        $error = "Payment failed: " . $e->getMessage();
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Payment | Smart HealthHub</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body {
            font-family: 'Segoe UI', sans-serif;
            background: #f5f7fa;
            margin: 0;
            padding: 0;
        }

        .navbar {
            background: linear-gradient(to right, #0077b6, #00b4d8);
            padding: 15px 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }

        .logo {
            color: white;
            font-size: 1.5rem;
            font-weight: bold;
        }

        .nav-links {
            display: flex;
            gap: 20px;
        }

        .nav-links a {
            color: white;
            text-decoration: none;
            font-weight: 500;
            transition: all 0.3s;
        }

        .nav-links a:hover {
            opacity: 0.8;
        }

        .payment-container {
            max-width: 600px;
            margin: 40px auto;
            background: white;
            border-radius: 12px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.05);
            padding: 30px;
            animation: fadeIn 0.5s ease;
        }

        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }

        .payment-header {
            text-align: center;
            margin-bottom: 30px;
        }

        .payment-header h2 {
            color: #0072bc;
            margin-bottom: 10px;
        }

        .payment-header p {
            color: #666;
        }

        .payment-amount {
            background: #f8f9fa;
            padding: 15px;
            border-radius: 8px;
            text-align: center;
            margin-bottom: 25px;
            font-size: 1.2rem;
            font-weight: bold;
        }

        .payment-form .form-group {
            margin-bottom: 20px;
        }

        .payment-form label {
            display: block;
            margin-bottom: 8px;
            font-weight: 500;
            color: #333;
        }

        .payment-form input {
            width: 100%;
            padding: 12px 15px;
            border: 1px solid #ddd;
            border-radius: 8px;
            font-size: 1rem;
            transition: all 0.3s;
        }

        .payment-form input:focus {
            border-color: #0072bc;
            outline: none;
            box-shadow: 0 0 0 3px rgba(0, 114, 188, 0.1);
        }

        .card-icons {
            display: flex;
            gap: 10px;
            margin-top: 10px;
        }

        .card-icons i {
            font-size: 1.8rem;
            color: #555;
        }

        .payment-btn {
            width: 100%;
            padding: 14px;
            background: #28a745;
            color: white;
            border: none;
            border-radius: 8px;
            font-size: 1rem;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
            margin-top: 10px;
        }

        .payment-btn:hover {
            background: #218838;
            transform: translateY(-2px);
        }

        .payment-btn:active {
            transform: translateY(0);
        }

        .error-message {
            color: #dc3545;
            text-align: center;
            margin-top: 15px;
            font-weight: 500;
        }

        .test-cards {
            margin-top: 30px;
            padding: 15px;
            background: #f8f9fa;
            border-radius: 8px;
            font-size: 0.9rem;
        }

        .test-cards h4 {
            margin-top: 0;
            color: #333;
        }

        .test-cards ul {
            padding-left: 20px;
            margin-bottom: 0;
        }

        @media (max-width: 768px) {
            .payment-container {
                margin: 20px;
                padding: 20px;
            }
        }
    </style>
</head>
<body>

<!-- NAVBAR -->
<div class="navbar">
    <div class="logo">Smart HealthHub</div>
    <div class="nav-links">
        <a href="dashboard.php">Dashboard</a>
        <a href="cart.php">Cart</a>
        <a href="logout.php">Logout</a>
    </div>
</div>

<div class="payment-container">
    <div class="payment-header">
        <h2><i class="fas fa-credit-card"></i> Payment</h2>
        <p>Complete your purchase with a secure payment</p>
    </div>

    <div class="payment-amount">
        Total Amount: ₹<?php echo number_format($total, 2); ?>
    </div>

    <?php if (isset($error)): ?>
        <div class="error-message">
            <i class="fas fa-exclamation-circle"></i> <?php echo $error; ?>
        </div>
    <?php endif; ?>

    <form class="payment-form" method="POST">
        <div class="form-group">
            <label for="card-number">Card Number</label>
            <input type="text" id="card-number" name="card_number" placeholder="1234 5678 9012 3456" required>
            <div class="card-icons">
                <i class="fab fa-cc-visa"></i>
                <i class="fab fa-cc-mastercard"></i>
                <i class="fab fa-cc-amex"></i>
                <i class="fab fa-cc-discover"></i>
            </div>
        </div>

        <div class="form-group">
            <label for="card-name">Name on Card</label>
            <input type="text" id="card-name" name="card_name" placeholder="John Doe" required>
        </div>

        <div style="display: flex; gap: 20px;">
            <div class="form-group" style="flex: 1;">
                <label for="expiry">Expiry Date</label>
                <input type="text" id="expiry" name="expiry" placeholder="MM/YY" required>
            </div>
            <div class="form-group" style="flex: 1;">
                <label for="cvv">CVV</label>
                <input type="text" id="cvv" name="cvv" placeholder="123" required>
            </div>
        </div>

        <button type="submit" name="pay" class="payment-btn">
            <i class="fas fa-lock"></i> Pay ₹<?php echo number_format($total, 2); ?>
        </button>
    </form>

    <div class="test-cards">
        <h4><i class="fas fa-info-circle"></i> Test Card Details</h4>
        <ul>
            <li>Card Number: 4242 4242 4242 4242</li>
            <li>Expiry: Any future date</li>
            <li>CVV: Any 3 digits</li>
        </ul>
    </div>
</div>

</body>
</html>