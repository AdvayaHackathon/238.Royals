<?php
require_once "../includes/auth.php"; // Checks if session is active
require_once "../config/db.php";     // PDO connection

$successMessage = null;
$doctors = [];

// Fetch doctors from DB
try {
    $stmt = $conn->query("SELECT id, name FROM doctors ORDER BY name");
    $doctors = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    echo "<script>alert('Failed to load doctors: " . $e->getMessage() . "');</script>";
}

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $userId = $_SESSION['user_id'];
    $type = $_POST['type'];
    $message = trim($_POST['message']);
    $rating = intval($_POST['rating']);
    $doctorId = $_POST['doctor_id'] ?? null;

    if (!empty($message) && in_array($type, ['doctor', 'website']) && $rating >= 1 && $rating <= 5) {
        try {
            if ($type === 'doctor' && $doctorId) {
                $stmt = $conn->prepare("INSERT INTO feedbacks (user_id, type, doctor_id, message, rating) 
                                        VALUES (:user_id, :type, :doctor_id, :message, :rating)");
                $stmt->execute([
                    ':user_id' => $userId,
                    ':type' => $type,
                    ':doctor_id' => $doctorId,
                    ':message' => $message,
                    ':rating' => $rating
                ]);
            } else {
                $stmt = $conn->prepare("INSERT INTO feedbacks (user_id, type, message, rating) 
                                        VALUES (:user_id, :type, :message, :rating)");
                $stmt->execute([
                    ':user_id' => $userId,
                    ':type' => $type,
                    ':message' => $message,
                    ':rating' => $rating
                ]);
            }

            $successMessage = "Thank you! Your feedback has been submitted successfully.";
        } catch (PDOException $e) {
            echo "<script>alert('Database error: " . $e->getMessage() . "');</script>";
        }
    } else {
        echo "<script>alert('Invalid input!');</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Feedback - Smart HealthHub</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body {
            font-family: 'Poppins', sans-serif;
            background: linear-gradient(135deg, #0f0c29, #302b63, #24243e);
            color: white;
            margin: 0;
            padding: 0;
        }
        .container {
            max-width: 900px;
            margin: 100px auto;
            padding: 40px;
            background: rgba(255, 255, 255, 0.05);
            border-radius: 16px;
            backdrop-filter: blur(10px);
            box-shadow: 0 4px 20px rgba(0,0,0,0.3);
        }
        h2 {
            font-size: 2rem;
            margin-bottom: 20px;
            background: linear-gradient(to right, #4cc9f0, #9b5de5);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }
        form {
            display: flex;
            flex-direction: column;
            gap: 20px;
        }
        label {
            font-weight: 500;
        }
        select, textarea, input[type="submit"] {
            padding: 12px 16px;
            font-size: 1rem;
            border-radius: 10px;
            border: none;
            font-family: 'Poppins', sans-serif;
            background: rgba(255,255,255,0.08);
            color: #fff;
            border: 1px solid rgba(255,255,255,0.1);
        }
        textarea {
            resize: vertical;
            min-height: 120px;
        }
        .rating {
            display: flex;
            gap: 5px;
        }
        .rating input {
            display: none;
        }
        .rating label {
            font-size: 1.5rem;
            color: #ccc;
            cursor: pointer;
        }
        .rating input:checked ~ label,
        .rating label:hover,
        .rating label:hover ~ label {
            color: #fbc02d;
        }
        input[type="submit"] {
            background: linear-gradient(to right, #4cc9f0, #9b5de5);
            color: white;
            font-weight: 600;
            cursor: pointer;
            text-transform: uppercase;
        }
        input[type="submit"]:hover {
            box-shadow: 0 6px 25px rgba(106, 76, 147, 0.6);
            transform: translateY(-2px);
        }
        .success-message {
            background-color: #4caf50;
            color: white;
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 30px;
            text-align: center;
        }
        @media (max-width: 768px) {
            .container {
                margin: 80px 20px;
                padding: 20px;
            }
        }
    </style>
</head>
<body>
<div class="container">

    <?php if ($successMessage): ?>
        <div class="success-message">
            <?= htmlspecialchars($successMessage) ?>
        </div>
    <?php endif; ?>

    <h2>Doctor Feedback</h2>
    <form method="POST">
        <input type="hidden" name="type" value="doctor">

        <label for="doctor">Select Doctor:</label>
        <select id="doctor" name="doctor_id" required>
            <?php foreach ($doctors as $doc): ?>
                <option value="<?= htmlspecialchars($doc['id']) ?>">
                    <?= htmlspecialchars($doc['name']) ?>
                </option>
            <?php endforeach; ?>
        </select>

        <label>Rate the Doctor:</label>
        <div class="rating">
            <?php for ($i = 5; $i >= 1; $i--): ?>
                <input type="radio" id="star<?= $i ?>" name="rating" value="<?= $i ?>" required>
                <label for="star<?= $i ?>">★</label>
            <?php endfor; ?>
        </div>

        <label for="message">Your Feedback:</label>
        <textarea name="message" id="message" placeholder="Write your experience..." required></textarea>

        <input type="submit" value="Submit Doctor Feedback">
    </form>

    <hr style="margin: 50px 0; border-color: rgba(255,255,255,0.1);">

    <h2>Website Feedback</h2>
    <form method="POST">
        <input type="hidden" name="type" value="website">

        <label>Rate the Platform:</label>
        <div class="rating">
            <?php for ($i = 5; $i >= 1; $i--): ?>
                <input type="radio" id="site-star<?= $i ?>" name="rating" value="<?= $i ?>" required>
                <label for="site-star<?= $i ?>">★</label>
            <?php endfor; ?>
        </div>

        <label for="site_message">Your Suggestions / Experience:</label>
        <textarea name="message" id="site_message" placeholder="We’d love your thoughts..." required></textarea>

        <input type="submit" value="Submit Website Feedback">
    </form>
</div>
</body>
</html>
