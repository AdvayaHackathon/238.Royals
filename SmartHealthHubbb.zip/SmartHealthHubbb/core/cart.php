<?php
require_once "../includes/auth.php";
require_once "../config/db.php";
require_once "../includes/functions.php";

$userId = $_SESSION['user_id'];
$msg = "";

// Auto-update quantity when changed
if (isset($_POST['quantity'])) {
    $cartId = $_POST['cart_id'];
    $newQty = $_POST['quantity'];
    $stmt = $conn->prepare("UPDATE cart SET quantity = ? WHERE id = ? AND user_id = ?");
    $stmt->execute([$newQty, $cartId, $userId]);
    $msg = "Quantity updated!";
}

// Remove item
if (isset($_POST['remove'])) {
    $cartId = $_POST['cart_id'];
    $stmt = $conn->prepare("DELETE FROM cart WHERE id = ? AND user_id = ?");
    $stmt->execute([$cartId, $userId]);
    $msg = "Item removed!";
}

// Handle checkout
if (isset($_POST['checkout'])) {
    $_SESSION['checkout_total'] = $_POST['total_amount'];
    header("Location: dummy_payment.php");
    exit();
}

// Fetch cart items
$stmt = $conn->prepare("SELECT c.id AS cart_id, m.*, c.quantity FROM cart c JOIN medicines m ON c.medicine_id = m.id WHERE c.user_id = ?");
$stmt->execute([$userId]);
$cartItems = $stmt->fetchAll(PDO::FETCH_ASSOC);

$total = 0;
?>

<!DOCTYPE html>
<html>
<head>
    <title>Your Cart - Smart HealthHub</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary: #0072bc;
            --primary-dark: #005f98;
            --secondary: #e67e22;
            --danger: #f44336;
            --success: #4CAF50;
            --light: #f8f9fa;
            --dark: #343a40;
            --gray: #6c757d;
        }
        
        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f2f7ff;
            color: #333;
            line-height: 1.6;
        }
        
        /* Navigation */
        .navbar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            background: linear-gradient(135deg, #0077b6 0%, #00b4d8 100%);
            padding: 15px 40px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
            position: sticky;
            top: 0;
            z-index: 1000;
        }
        
        .navbar .logo {
            font-size: 1.8rem;
            color: white;
            font-weight: 700;
            letter-spacing: 0.5px;
        }
        
        .nav-menu {
            display: flex;
            list-style: none;
            gap: 25px;
        }
        
        .nav-menu li a {
            color: white;
            text-decoration: none;
            font-size: 1rem;
            font-weight: 500;
            padding: 8px 15px;
            border-radius: 6px;
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
            gap: 8px;
        }
        
        .nav-menu li a:hover {
            background-color: rgba(255, 255, 255, 0.15);
        }
        
        .nav-menu li a i {
            font-size: 1.1rem;
        }
        
        /* Main Content */
        .container {
            max-width: 1200px;
            margin: 30px auto;
            padding: 0 20px;
        }
        
        .page-title {
            text-align: center;
            color: var(--primary);
            margin-bottom: 30px;
            font-size: 2.2rem;
            position: relative;
            padding-bottom: 15px;
        }
        
        .page-title::after {
            content: '';
            position: absolute;
            bottom: 0;
            left: 50%;
            transform: translateX(-50%);
            width: 100px;
            height: 3px;
            background: linear-gradient(90deg, var(--primary) 0%, rgba(0,114,188,0.1) 100%);
            border-radius: 3px;
        }
        
        /* Cart Styles */
        .cart-container {
            background: white;
            border-radius: 12px;
            box-shadow: 0 8px 30px rgba(0, 0, 0, 0.05);
            padding: 30px;
            margin-bottom: 40px;
        }
        
        .alert {
            padding: 12px 20px;
            border-radius: 8px;
            margin-bottom: 20px;
            font-weight: 500;
            text-align: center;
            animation: fadeIn 0.5s ease-out;
        }
        
        .alert-success {
            background-color: rgba(76, 175, 80, 0.15);
            color: var(--success);
            border: 1px solid rgba(76, 175, 80, 0.3);
        }
        
        /* Cart Table */
        .cart-table {
            width: 100%;
            border-collapse: collapse;
            margin: 25px 0;
            font-size: 0.95rem;
            animation: slideUp 0.5s ease-out;
        }
        
        .cart-table thead tr {
            background-color: var(--primary);
            color: white;
            text-align: left;
        }
        
        .cart-table th,
        .cart-table td {
            padding: 15px 20px;
            text-align: center;
        }
        
        .cart-table tbody tr {
            border-bottom: 1px solid #eee;
            transition: all 0.3s;
        }
        
        .cart-table tbody tr:nth-child(even) {
            background-color: #f9f9f9;
        }
        
        .cart-table tbody tr:hover {
            background-color: #f1f7ff;
        }
        
        .cart-table tbody tr:last-child {
            border-bottom: 2px solid var(--primary);
        }
        
        .product-img {
            width: 70px;
            height: 70px;
            object-fit: contain;
            border-radius: 8px;
            border: 1px solid #eee;
            padding: 5px;
            background: white;
        }
        
        .product-name {
            font-weight: 600;
            color: var(--dark);
        }
        
        .product-price {
            font-weight: 700;
            color: var(--primary);
        }
        
        .quantity-input {
            width: 70px;
            padding: 8px 10px;
            border: 1px solid #ddd;
            border-radius: 6px;
            text-align: center;
            font-weight: 500;
        }
        
        .btn {
            display: inline-block;
            padding: 8px 16px;
            border-radius: 6px;
            font-weight: 500;
            cursor: pointer;
            transition: all 0.3s;
            border: none;
            font-size: 0.95rem;
        }
        
        .btn-danger {
            background-color: var(--danger);
            color: white;
        }
        
        .btn-danger:hover {
            background-color: #d32f2f;
            transform: translateY(-2px);
        }
        
        .btn-primary {
            background-color: var(--primary);
            color: white;
        }
        
        .btn-primary:hover {
            background-color: var(--primary-dark);
            transform: translateY(-2px);
        }
        
        .btn i {
            margin-right: 6px;
        }
        
        .total-row {
            background-color: #f1f7ff !important;
            font-weight: 700;
            font-size: 1.1rem;
        }
        
        .total-label {
            text-align: right;
            padding-right: 20px !important;
        }
        
        .checkout-btn {
            display: block;
            width: 100%;
            max-width: 300px;
            margin: 30px auto 0;
            padding: 12px;
            font-size: 1.1rem;
            text-align: center;
        }
        
        /* Empty Cart */
        .empty-cart {
            text-align: center;
            padding: 50px 20px;
            background-color: white;
            border-radius: 12px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.05);
            margin: 30px 0;
        }
        
        .empty-cart-icon {
            font-size: 5rem;
            color: var(--gray);
            margin-bottom: 20px;
            opacity: 0.7;
        }
        
        .empty-cart h3 {
            color: var(--dark);
            margin-bottom: 15px;
            font-size: 1.5rem;
        }
        
        .empty-cart p {
            color: var(--gray);
            margin-bottom: 25px;
            max-width: 500px;
            margin-left: auto;
            margin-right: auto;
        }
        
        .shop-btn {
            display: inline-block;
            padding: 12px 30px;
            background-color: var(--primary);
            color: white;
            text-decoration: none;
            border-radius: 8px;
            font-weight: 600;
            transition: all 0.3s;
            box-shadow: 0 4px 12px rgba(0, 114, 188, 0.2);
        }
        
        .shop-btn:hover {
            background-color: var(--primary-dark);
            transform: translateY(-3px);
            box-shadow: 0 6px 16px rgba(0, 114, 188, 0.3);
        }
        
        /* Animations */
        @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }
        
        @keyframes slideUp {
            from { 
                opacity: 0;
                transform: translateY(20px);
            }
            to { 
                opacity: 1;
                transform: translateY(0);
            }
        }
        
        /* Responsive */
        @media (max-width: 992px) {
            .navbar {
                padding: 15px 25px;
            }
            
            .nav-menu {
                gap: 15px;
            }
        }
        
        @media (max-width: 768px) {
            .navbar {
                flex-direction: column;
                gap: 15px;
                padding: 15px;
            }
            
            .nav-menu {
                width: 100%;
                justify-content: center;
                flex-wrap: wrap;
            }
            
            .container {
                padding: 0 15px;
            }
            
            .cart-container {
                padding: 20px 15px;
            }
            
            .cart-table thead {
                display: none;
            }
            
            .cart-table tbody tr {
                display: block;
                margin-bottom: 20px;
                border: 1px solid #ddd;
                border-radius: 8px;
                padding: 10px;
            }
            
            .cart-table td {
                display: flex;
                justify-content: space-between;
                align-items: center;
                padding: 10px 15px;
                text-align: right;
                border-bottom: 1px solid #eee;
            }
            
            .cart-table td::before {
                content: attr(data-label);
                font-weight: 600;
                color: var(--primary);
                margin-right: auto;
                padding-right: 20px;
                text-align: left;
            }
            
            .cart-table td:last-child {
                border-bottom: none;
            }
            
            .product-img {
                margin: 0 auto;
            }
            
            .total-row td {
                display: table-cell;
                text-align: center;
            }
            
            .total-label {
                text-align: center !important;
            }
        }
    </style>
</head>
<body>
<!-- Navigation -->
<nav class="navbar">
    <div class="logo">Smart HealthHub</div>
    <ul class="nav-menu">
        <li><a href="dashboard.php"><i class="fas fa-home"></i> Dashboard</a></li>
        <li><a href="appointments.php"><i class="fas fa-calendar-check"></i> Appointments</a></li>
        <li><a href="e-medical.php"><i class="fas fa-pills"></i> E-Medical Store</a></li>
        <li><a href="chatbot.php"><i class="fas fa-robot"></i> AI Chatbot</a></li>
        <li><a href="profile.php"><i class="fas fa-user"></i> Profile</a></li>
        <li><a href="logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a></li>
    </ul>
</nav>

<!-- Main Content -->
<div class="container">
    <h1 class="page-title"><i class="fas fa-shopping-cart"></i> Your Shopping Cart</h1>
    
    <?php if ($msg): ?>
        <div class="alert alert-success"><?php echo $msg; ?></div>
    <?php endif; ?>
    
    <div class="cart-container">
        <?php if (count($cartItems) > 0): ?>
            <table class="cart-table">
                <thead>
                    <tr>
                        <th>Product</th>
                        <th>Price</th>
                        <th>Quantity</th>
                        <th>Subtotal</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($cartItems as $item): 
                        $subtotal = $item['price'] * $item['quantity'];
                        $total += $subtotal;
                    ?>
                        <tr>
                            <td data-label="Product">
                                <div style="display: flex; align-items: center; gap: 15px;">
                                    <img src="../assets/images/meds/<?php echo $item['image'] ?: 'default.png'; ?>" class="product-img">
                                    <span class="product-name"><?php echo $item['name']; ?></span>
                                </div>
                            </td>
                            <td data-label="Price" class="product-price">₹<?php echo $item['price']; ?></td>
                            <td data-label="Quantity">
                                <form method="POST" style="display: flex; justify-content: center;">
                                    <input type="hidden" name="cart_id" value="<?php echo $item['cart_id']; ?>">
                                    <input type="number" name="quantity" value="<?php echo $item['quantity']; ?>" 
                                           min="1" max="<?php echo $item['stock']; ?>" 
                                           class="quantity-input" onchange="this.form.submit()">
                                </form>
                            </td>
                            <td data-label="Subtotal" class="product-price">₹<?php echo number_format($subtotal, 2); ?></td>
                            <td data-label="Action">
                                <form method="POST">
                                    <input type="hidden" name="cart_id" value="<?php echo $item['cart_id']; ?>">
                                    <button type="submit" name="remove" class="btn btn-danger">
                                        <i class="fas fa-trash-alt"></i> Remove
                                    </button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                    <tr class="total-row">
                        <td colspan="3" class="total-label">Total Amount:</td>
                        <td colspan="2" class="product-price">₹<?php echo number_format($total, 2); ?></td>
                    </tr>
                </tbody>
            </table>
            
            <form action="" method="POST">
                <input type="hidden" name="total_amount" value="<?php echo $total; ?>">
                <button type="submit" name="checkout" class="btn btn-primary checkout-btn">
                    <i class="fas fa-credit-card"></i> Proceed to Checkout
                </button>
            </form>
            
        <?php else: ?>
            <div class="empty-cart">
                <div class="empty-cart-icon">
                    <i class="fas fa-shopping-cart"></i>
                </div>
                <h3>Your Cart is Empty</h3>
                <p>Looks like you haven't added anything to your cart yet. Start shopping to find amazing products!</p>
                <a href="e-medical.php" class="shop-btn">
                    <i class="fas fa-arrow-left"></i> Continue Shopping
                </a>
            </div>
        <?php endif; ?>
    </div>
</div>

<?php require_once "../includes/footer.php"; ?>
</body>
</html>