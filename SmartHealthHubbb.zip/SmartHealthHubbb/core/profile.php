<?php
session_start();
require_once "../config/db.php";
require_once "../includes/auth.php";

$userId = $_SESSION['user_id'];

// Fetch user info with blood group and dob
$stmt = $conn->prepare("SELECT full_name, email, role, created_at, blood_group, date_of_birth FROM users WHERE id = ?");
$stmt->execute([$userId]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Your Profile - Smart HealthHub</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary: #6a4c93;
            --primary-dark: #4a2c7a;
            --primary-light: #8f6cb3;
            --secondary: #3f37c9;
            --accent: #4cc9f0;
            --success: #4ad66d;
            --error: #f72585;
            --warning: #f8961e;
            --light: #f8f9fa;
            --dark: #212529;
            --gray: #6c757d;
            --light-gray: #e9ecef;
            --shadow-sm: 0 1px 3px rgba(0, 0, 0, 0.1);
            --shadow-md: 0 4px 6px rgba(0, 0, 0, 0.15);
            --shadow-lg: 0 10px 25px rgba(0, 0, 0, 0.2);
            --transition: all 0.3s cubic-bezier(0.25, 0.8, 0.25, 1);
            --border-radius: 16px;
            --glass-effect: rgba(255, 255, 255, 0.2);
            --nav-height: 80px;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Poppins', sans-serif;
            background: linear-gradient(135deg, #0f0c29 0%, #302b63 50%, #24243e 100%);
            color: white;
            min-height: 100vh;
            display: flex;
            flex-direction: column;
            line-height: 1.6;
            position: relative;
            overflow-x: hidden;
        }

        /* Navigation */
        .navbar {
            background: rgba(15, 12, 41, 0.8);
            backdrop-filter: blur(10px);
            -webkit-backdrop-filter: blur(10px);
            height: var(--nav-height);
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 0 40px;
            position: fixed;
            width: 100%;
            top: 0;
            z-index: 1000;
            box-shadow: 0 2px 20px rgba(0, 0, 0, 0.3);
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        }

        .logo {
            display: flex;
            align-items: center;
            gap: 10px;
            font-size: 1.5rem;
            font-weight: 700;
            color: white;
            text-decoration: none;
        }

        .logo i {
            color: var(--accent);
        }

        .nav-links {
            display: flex;
            gap: 30px;
        }

        .nav-links a {
            color: white;
            text-decoration: none;
            font-weight: 500;
            position: relative;
            padding: 5px 0;
            transition: var(--transition);
        }

        .nav-links a::after {
            content: '';
            position: absolute;
            bottom: 0;
            left: 0;
            width: 0;
            height: 2px;
            background: linear-gradient(to right, var(--accent), var(--primary-light));
            transition: var(--transition);
        }

        .nav-links a:hover::after {
            width: 100%;
        }

        .nav-links a:hover {
            color: var(--accent);
        }

        .user-menu {
            display: flex;
            align-items: center;
            gap: 20px;
        }

        .user-menu .profile {
            display: flex;
            align-items: center;
            gap: 10px;
            cursor: pointer;
            position: relative;
        }

        .user-menu .profile img {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            object-fit: cover;
            border: 2px solid var(--accent);
        }

        .user-menu .profile-name {
            font-weight: 500;
        }

        .dropdown-menu {
            position: absolute;
            top: 60px;
            right: 0;
            background: rgba(15, 12, 41, 0.95);
            border-radius: var(--border-radius);
            padding: 15px 0;
            min-width: 200px;
            box-shadow: var(--shadow-lg);
            opacity: 0;
            visibility: hidden;
            transform: translateY(10px);
            transition: var(--transition);
            z-index: 1001;
            border: 1px solid rgba(255, 255, 255, 0.1);
        }

        .profile:hover .dropdown-menu {
            opacity: 1;
            visibility: visible;
            transform: translateY(0);
        }

        .dropdown-menu a {
            display: block;
            padding: 10px 20px;
            color: white;
            text-decoration: none;
            transition: var(--transition);
        }

        .dropdown-menu a:hover {
            background: rgba(255, 255, 255, 0.1);
            color: var(--accent);
        }

        .dropdown-menu a i {
            margin-right: 10px;
            width: 20px;
            text-align: center;
        }

        /* Main content */
        .profile-container {
            max-width: 800px;
            margin: calc(var(--nav-height) + 30px) auto 30px;
            padding: 30px;
            flex: 1;
        }

        .profile-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
        }

        .profile-header h2 {
            font-size: 2rem;
            color: white;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .profile-header h2 i {
            color: var(--accent);
        }

        .profile-card {
            background: rgba(255, 255, 255, 0.05);
            backdrop-filter: blur(10px);
            -webkit-backdrop-filter: blur(10px);
            border-radius: var(--border-radius);
            padding: 30px;
            box-shadow: var(--shadow-md);
            border: 1px solid rgba(255, 255, 255, 0.1);
        }

        .profile-info {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 20px;
        }

        .info-group {
            margin-bottom: 20px;
        }

        .info-group h4 {
            color: var(--accent);
            margin-bottom: 8px;
            font-size: 0.9rem;
            text-transform: uppercase;
            letter-spacing: 1px;
        }

        .info-group p {
            background: rgba(255, 255, 255, 0.1);
            padding: 12px 15px;
            border-radius: 8px;
            border-left: 3px solid var(--accent);
        }

        .empty-field {
            color: rgba(255, 255, 255, 0.5);
            font-style: italic;
        }

        /* Footer */
        .footer {
            background: rgba(15, 12, 41, 0.8);
            backdrop-filter: blur(10px);
            -webkit-backdrop-filter: blur(10px);
            padding: 20px 0;
            text-align: center;
            color: rgba(255, 255, 255, 0.7);
            font-size: 0.9rem;
            border-top: 1px solid rgba(255, 255, 255, 0.1);
        }

        /* Responsive */
        @media (max-width: 768px) {
            .profile-info {
                grid-template-columns: 1fr;
            }
            
            .profile-container {
                padding: 20px;
            }
        }

        @media (max-width: 576px) {
            .profile-card {
                padding: 20px;
            }
        }
    </style>
</head>
<body>
    <!-- Navigation -->
    <nav class="navbar">
        <a href="#" class="logo">
            <i class="fas fa-heartbeat"></i>
            <span>Smart HealthHub</span>
        </a>
        
        <div class="nav-links">
            <a href="dashboard.php"><i class="fas fa-home"></i> Dashboard</a>
            <a href="appointments.php"><i class="fas fa-calendar-alt"></i> Appointments</a>
            <a href="feedback.php"><i class="fas fa-comment-alt"></i> Feedback</a>
            <a href="settings.php"><i class="fas fa-cog"></i> Settings</a>
        </div>
        
        <div class="user-menu">
            <div class="profile">
                <img src="../assets/images/default-profile.jpg" alt="Profile">
                <span class="profile-name"><?= htmlspecialchars($_SESSION['user_name']) ?></span>
                
                <div class="dropdown-menu">
                    <a href="profile.php"><i class="fas fa-user-circle"></i> Profile</a>
                    <a href="orders.php"><i class="fas fa-history"></i> Order History</a>
                    <a href="../includes/logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a>
                </div>
            </div>
        </div>
    </nav>

    <div class="profile-container">
        <div class="profile-header">
            <h2><i class="fas fa-user-circle"></i> Your Profile</h2>
        </div>
        
        <div class="profile-card">
            <div class="profile-info">
                <div class="info-group">
                    <h4>Full Name</h4>
                    <p><?= htmlspecialchars($user['full_name']) ?></p>
                </div>
                
                <div class="info-group">
                    <h4>Email Address</h4>
                    <p><?= htmlspecialchars($user['email']) ?></p>
                </div>
                
                <div class="info-group">
                    <h4>Member Since</h4>
                    <p><?= date('F j, Y', strtotime($user['created_at'])) ?></p>
                </div>
                
                <div class="info-group">
                    <h4>Blood Group</h4>
                    <p><?= !empty($user['blood_group']) ? htmlspecialchars($user['blood_group']) : '<span class="empty-field">Not specified</span>' ?></p>
                </div>
                
                <div class="info-group">
                    <h4>Date of Birth</h4>
                    <p><?= !empty($user['date_of_birth']) ? date('F j, Y', strtotime($user['date_of_birth'])) : '<span class="empty-field">Not specified</span>' ?></p>
                </div>
            </div>
        </div>
    </div>

    <footer class="footer">
        <p>&copy; <?= date('Y') ?> Smart HealthHub. All rights reserved.</p>
    </footer>
</body>
</html>