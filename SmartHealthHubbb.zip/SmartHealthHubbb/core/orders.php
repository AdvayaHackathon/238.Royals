<?php
require_once "../includes/auth.php";
require_once "../config/db.php";
require_once "../includes/functions.php";
// require_once "../includes/navbar.php";

$userId = $_SESSION['user_id'];

// Show success message if redirected from payment
if (isset($_SESSION['order_success'])) {
    $successMsg = "Your order has been placed successfully!";
    unset($_SESSION['order_success']);
}

// Fetch all orders
$stmt = $conn->prepare("SELECT * FROM orders WHERE user_id = ? ORDER BY order_date DESC");
$stmt->execute([$userId]);
$orders = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html>
<head>
    <title>Your Orders</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        .dashboard-container {
            max-width: 1000px;
            margin: 30px auto;
            padding: 30px;
            background: white;
            border-radius: 12px;
            box-shadow: 0 0 20px rgba(0,0,0,0.05);
        }
        
        h2 {
            color: #0072bc;
            text-align: center;
            margin-bottom: 30px;
        }
        
        .order-card {
            border: 1px solid #e0e0e0;
            border-radius: 10px;
            padding: 20px;
            margin-bottom: 30px;
            background: #f9fbfd;
            box-shadow: 0 2px 10px rgba(0,0,0,0.03);
        }
        
        .order-card h3 {
            color: #0072bc;
            margin-top: 0;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .order-card p {
            margin: 8px 0;
            color: #555;
        }
        
        table {
            width: 100%;
            border-collapse: collapse;
            margin: 15px 0;
            background: white;
        }
        
        th, td {
            padding: 12px 15px;
            text-align: left;
            border-bottom: 1px solid #e0e0e0;
        }
        
        th {
            background: #f2f7ff;
            color: #0072bc;
            font-weight: 600;
        }
        
        tr:hover {
            background-color: #f8fafc;
        }
        
        .no-orders {
            text-align: center;
            padding: 40px;
            background: #f8f9fa;
            border-radius: 10px;
        }
        
        .no-orders i {
            font-size: 50px;
            color: #6c757d;
            margin-bottom: 20px;
        }
        
        .no-orders a {
            display: inline-block;
            margin-top: 15px;
            padding: 10px 20px;
            background: #0072bc;
            color: white;
            text-decoration: none;
            border-radius: 6px;
            transition: all 0.3s;
        }
        
        .no-orders a:hover {
            background: #005ea3;
        }
        
        .success-message {
            text-align: center;
            padding: 15px;
            background: #d4edda;
            color: #155724;
            border-radius: 6px;
            margin-bottom: 30px;
            animation: fadeIn 0.5s;
        }
        
        @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }
    </style>
</head>
<body>

<div class="dashboard-container">
    <h2><i class="fas fa-box-open"></i> Your Orders</h2>
    
    <?php if (isset($successMsg)): ?>
        <div class="success-message">
            <i class="fas fa-check-circle"></i> <?php echo $successMsg; ?>
        </div>
    <?php endif; ?>

    <?php if (count($orders) > 0): ?>
        <?php foreach ($orders as $order): ?>
            <div class="order-card">
                <h3>
                    <span>🧾 Order #<?php echo $order['id']; ?></span>
                    <span>₹<?php echo number_format($order['total_amount'], 2); ?></span>
                </h3>
                <p><strong><i class="far fa-calendar-alt"></i> Placed On:</strong> <?php echo date('F j, Y, g:i a', strtotime($order['order_date'])); ?></p>
                <p><strong><i class="fas fa-info-circle"></i> Status:</strong> <?php echo $order['status'] ?? 'Completed'; ?></p>

                <table>
                    <thead>
                        <tr>
                            <th>Medicine</th>
                            <th>Quantity</th>
                            <th>Price</th>
                            <th>Subtotal</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $stmtItems = $conn->prepare("SELECT oi.quantity, oi.price, m.name FROM order_items oi JOIN medicines m ON oi.medicine_id = m.id WHERE oi.order_id = ?");
                        $stmtItems->execute([$order['id']]);
                        $items = $stmtItems->fetchAll(PDO::FETCH_ASSOC);

                        foreach ($items as $item): 
                            $subtotal = $item['price'] * $item['quantity'];
                        ?>
                            <tr>
                                <td><?php echo $item['name']; ?></td>
                                <td><?php echo $item['quantity']; ?></td>
                                <td>₹<?php echo number_format($item['price'], 2); ?></td>
                                <td>₹<?php echo number_format($subtotal, 2); ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php endforeach; ?>
    <?php else: ?>
        <div class="no-orders">
            <i class="fas fa-box-open"></i>
            <h3>No orders yet</h3>
            <p>You haven't placed any orders yet</p>
            <a href="e-medical.php"><i class="fas fa-shopping-cart"></i> Start Shopping</a>
        </div>
    <?php endif; ?>
</div>

<?php require_once "../includes/footer.php"; ?>
</body>
</html>