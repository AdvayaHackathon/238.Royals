<?php
require_once "../includes/auth.php";
require_once "../config/db.php";
require_once "../includes/functions.php";

$userId = $_SESSION['user_id'];

// Fetch all medicines
$meds = $conn->query("SELECT * FROM medicines")->fetchAll(PDO::FETCH_ASSOC);

// Fetch distinct categories
$categoryStmt = $conn->query("SELECT DISTINCT category FROM medicines");
$categories = $categoryStmt->fetchAll(PDO::FETCH_COLUMN);
?>
<!DOCTYPE html>
<html>
<head>
    <title>e-Medical Store</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body {
            margin: 0;
            padding: 0;
            font-family: 'Segoe UI', sans-serif;
            background-color: #f4f9ff;
            color: #333;
            animation: fadePage 0.8s ease-in;
        }

        @keyframes fadePage {
            from { opacity: 0; }
            to { opacity: 1; }
        }

        nav {
            background-color: #0072bc;
            padding: 16px 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            position: sticky;
            top: 0;
            z-index: 999;
            box-shadow: 0 2px 10px rgba(0,0,0,0.08);
        }

        .nav-logo {
            color: white;
            font-size: 22px;
            font-weight: bold;
        }

        .nav-links {
            display: flex;
            align-items: center;
            gap: 20px;
        }

        .nav-links a {
            color: white;
            text-decoration: none;
            font-size: 16px;
            transition: color 0.3s ease, transform 0.3s ease;
        }

        .nav-links a:hover {
            color: #ffe082;
            transform: scale(1.05);
        }

        .dashboard-container {
            padding: 40px 20px;
            max-width: 1200px;
            margin: auto;
        }

        h2 {
            text-align: center;
            color: #0072bc;
            font-size: 36px;
            margin-bottom: 20px;
            animation: fadeIn 1s ease;
        }

        .filters {
            display: flex;
            justify-content: center;
            gap: 15px;
            margin-bottom: 30px;
            flex-wrap: wrap;
        }

        .filters input, .filters select {
            padding: 12px 15px;
            border-radius: 8px;
            border: 1px solid #ccc;
            font-size: 14px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.05);
            transition: all 0.3s ease;
            min-width: 200px;
        }

        .filters input:focus, .filters select:focus {
            border-color: #0072bc;
            outline: none;
            box-shadow: 0 0 8px rgba(0,114,188,0.2);
        }

        .grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
            gap: 30px;
            animation: slideUp 1s ease;
        }

        .card {
            background-color: #fff;
            border-radius: 15px;
            padding: 20px;
            box-shadow: 0 6px 20px rgba(0, 114, 188, 0.08);
            transition: transform 0.3s ease, box-shadow 0.3s ease;
            position: relative;
            overflow: hidden;
        }

        .card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 30px rgba(0, 114, 188, 0.2);
        }

        .card img {
            width: 100%;
            height: 180px;
            object-fit: contain;
            border-radius: 12px;
            margin-bottom: 15px;
            background: #f8f9fa;
            padding: 10px;
        }

        .card h3 {
            color: #0072bc;
            font-size: 20px;
            margin-bottom: 8px;
        }

        .card p {
            margin: 5px 0;
            font-size: 14px;
            color: #555;
        }

        .card p strong {
            color: #e67e22;
        }

        .rating {
            color: gold;
            margin: 8px 0;
        }

        form {
            margin-top: 15px;
            display: flex;
            align-items: center;
            gap: 10px;
            flex-wrap: wrap;
        }

        input[type="number"] {
            width: 60px;
            padding: 8px;
            border: 1px solid #ddd;
            border-radius: 5px;
            text-align: center;
            font-size: 14px;
        }

        button {
            background-color: #0072bc;
            color: white;
            border: none;
            padding: 10px 18px;
            border-radius: 8px;
            cursor: pointer;
            transition: background-color 0.3s ease, transform 0.2s;
            font-size: 14px;
            flex-grow: 1;
        }

        button:hover {
            background-color: #005f98;
            transform: scale(1.03);
        }

        .view-cart {
            display: block;
            margin: 40px auto 0;
            text-align: center;
            color: #0072bc;
            text-decoration: none;
            font-weight: bold;
            transition: color 0.3s;
            padding: 12px 25px;
            border: 2px solid #0072bc;
            border-radius: 8px;
            max-width: 200px;
        }

        .view-cart:hover {
            color: #fff;
            background-color: #0072bc;
        }

        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(-10px); }
            to { opacity: 1; transform: translateY(0); }
        }

        @keyframes slideUp {
            from { opacity: 0; transform: translateY(30px); }
            to { opacity: 1; transform: translateY(0); }
        }

        /* Notification styles */
        .notification {
            position: fixed;
            top: 20px;
            right: 20px;
            padding: 15px 25px;
            background: #4CAF50;
            color: white;
            border-radius: 8px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.15);
            z-index: 1000;
            transform: translateX(150%);
            transition: transform 0.4s cubic-bezier(0.68, -0.55, 0.27, 1.55);
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        .notification.show {
            transform: translateX(0);
        }
        
        .notification.error {
            background: #f44336;
        }
        
        .notification i {
            font-size: 20px;
        }

        @media (max-width: 768px) {
            nav {
                flex-direction: column;
                gap: 15px;
                padding: 15px;
            }
            
            .nav-links {
                width: 100%;
                justify-content: space-around;
            }
            
            h2 {
                font-size: 28px;
            }
            
            .filters {
                flex-direction: column;
                align-items: center;
            }
            
            .filters input, .filters select {
                width: 100%;
            }
            
            .grid {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>
<body>
<nav>
    <div class="nav-logo">Smart HealthHub</div>
    <div class="nav-links">
        <a href="dashboard.php">Dashboard</a>
        <a href="chatbot.php">AI Chatbot</a>
        <a href="profile.php">Profile</a>
        <a href="cart.php" class="cart-link">
            <i class="fas fa-shopping-cart"></i>
            <span class="cart-count">0</span>
        </a>
    </div>
</nav>

<div class="dashboard-container">
    <h2>💊 Welcome to Your e-Medical Store</h2>

    <div class="filters">
        <input type="text" id="searchInput" placeholder="Search medicine..." onkeyup="filterMeds()">
        <select id="categoryFilter" onchange="filterMeds()">
            <option value="">All Categories</option>
            <?php foreach ($categories as $cat): ?>
                <option value="<?php echo htmlspecialchars($cat); ?>"><?php echo htmlspecialchars($cat); ?></option>
            <?php endforeach; ?>
        </select>
    </div>

    <div class="grid">
        <?php foreach ($meds as $med): ?>
            <div class="card" data-category="<?php echo htmlspecialchars($med['category']); ?>">
                <?php
                $image = !empty($med['image']) && file_exists(__DIR__ . "/../assets/images/meds/" . $med['image'])
                    ? $med['image']
                    : 'default.png';

                $rating = isset($med['rating']) ? $med['rating'] : number_format(rand(30, 50) / 10, 1);
                ?>
                <img src="../assets/images/meds/<?php echo htmlspecialchars($image); ?>" alt="<?php echo htmlspecialchars($med['name']); ?>">

                <h3><?php echo htmlspecialchars($med['name']); ?></h3>
                <p><?php echo htmlspecialchars($med['description']); ?></p>
                <p><strong>₹<?php echo $med['price']; ?></strong></p>
                <p>Stock: <?php echo $med['stock']; ?></p>
                <p class="rating">⭐ <?php echo $rating; ?>/5</p>
                <form class="add-to-cart-form" data-medicine-id="<?php echo $med['id']; ?>">
                    <input type="hidden" name="medicine_id" value="<?php echo $med['id']; ?>">
                    <input type="number" name="quantity" value="1" min="1" max="<?php echo $med['stock']; ?>">
                    <button type="submit" name="add_to_cart">🛒 Add to Cart</button>
                </form>
            </div>
        <?php endforeach; ?>
    </div>

    <a href="cart.php" class="view-cart">🛍 View Your Cart</a>
</div>

<!-- Notification element -->
<div class="notification" id="notification">
    <i class="fas fa-check-circle"></i>
    <span id="notification-message"></span>
</div>

<?php require_once "../includes/footer.php"; ?>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
    // Update cart count on page load
    $(document).ready(function() {
        updateCartCount();
    });

    function updateCartCount() {
        $.ajax({
            url: '../includes/get_cart_count.php',
            method: 'GET',
            success: function(response) {
                $('.cart-count').text(response);
            },
            error: function() {
                $('.cart-count').text('0');
            }
        });
    }

    function showNotification(message, isError = false) {
        const notification = $('#notification');
        const notificationMessage = $('#notification-message');
        
        notificationMessage.text(message);
        notification.removeClass('error show');
        
        if (isError) {
            notification.addClass('error');
            notification.find('i').removeClass('fa-check-circle').addClass('fa-exclamation-circle');
        } else {
            notification.find('i').removeClass('fa-exclamation-circle').addClass('fa-check-circle');
        }
        
        // Trigger reflow to restart animation
        void notification[0].offsetWidth;
        
        notification.addClass('show');
        
        setTimeout(() => {
            notification.removeClass('show');
        }, 3000);
    }

    // Handle add to cart with AJAX
    $(document).on('submit', '.add-to-cart-form', function(e) {
        e.preventDefault();
        
        const form = $(this);
        const button = form.find('button[type="submit"]');
        const originalText = button.html();
        
        // Show loading state
        button.html('<i class="fas fa-spinner fa-spin"></i> Adding...');
        button.prop('disabled', true);
        
        $.ajax({
            url: '../includes/add_to_cart.php',
            method: 'POST',
            data: form.serialize(),
            dataType: 'json',
            success: function(response) {
                if (response.success) {
                    showNotification(response.message);
                    updateCartCount();
                } else {
                    showNotification(response.message, true);
                }
            },
            error: function(xhr, status, error) {
                showNotification('An error occurred. Please try again.', true);
                console.error(error);
            },
            complete: function() {
                button.html(originalText);
                button.prop('disabled', false);
            }
        });
    });

    // Filter medicines
    function filterMeds() {
        const searchInput = document.getElementById('searchInput').value.toLowerCase();
        const categoryFilter = document.getElementById('categoryFilter').value;
        const cards = document.querySelectorAll('.card');

        cards.forEach(card => {
            const name = card.querySelector('h3').innerText.toLowerCase();
            const description = card.querySelector('p:nth-of-type(1)').innerText.toLowerCase();
            const category = card.getAttribute('data-category');
            
            const matchesSearch = name.includes(searchInput) || description.includes(searchInput);
            const matchesCategory = !categoryFilter || category === categoryFilter;
            
            card.style.display = matchesSearch && matchesCategory ? 'block' : 'none';
        });
    }
</script>
</body>
</html>