<?php
require_once "../includes/auth.php";
require_once "../config/db.php";
require_once "../includes/functions.php";

$userId = $_SESSION['user_id'];

// Handle appointment deletion
if (isset($_GET['delete_id'])) {
    $deleteId = $_GET['delete_id'];
    try {
        $stmt = $conn->prepare("DELETE FROM appointments WHERE id = ? AND user_id = ?");
        $stmt->execute([$deleteId, $userId]);

        $_SESSION['flash_message'] = [
            'type' => 'success',
            'message' => 'Appointment cancelled successfully!'
        ];
        header("Location: appointments.php");
        exit;
    } catch (PDOException $e) {
        $_SESSION['flash_message'] = [
            'type' => 'error',
            'message' => 'Error cancelling appointment: ' . $e->getMessage()
        ];
        header("Location: appointments.php");
        exit;
    }
}

// Booking appointment
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $doctorId = $_POST['doctor_id'];
    $date = $_POST['date'];
    $timeSlot = $_POST['time_slot'];

    try {
        $stmt = $conn->prepare("INSERT INTO appointments (user_id, doctor_id, date, time_slot) VALUES (?, ?, ?, ?)");
        $stmt->execute([$userId, $doctorId, $date, $timeSlot]);

        $_SESSION['flash_message'] = [
            'type' => 'success',
            'message' => 'Appointment booked successfully!'
        ];
        header("Location: appointments.php");
        exit;
    } catch (PDOException $e) {
        $_SESSION['flash_message'] = [
            'type' => 'error',
            'message' => 'Error booking appointment: ' . $e->getMessage()
        ];
        header("Location: appointments.php");
        exit;
    }
}

// Fetch doctors
$doctors = $conn->query("SELECT * FROM doctors")->fetchAll(PDO::FETCH_ASSOC);

// User's upcoming appointments
$stmt = $conn->prepare("SELECT a.*, d.name AS doctor_name, d.specialty, a.status 
                        FROM appointments a 
                        JOIN doctors d ON a.doctor_id = d.id 
                        WHERE a.user_id = ? 
                        ORDER BY a.date ASC");
$stmt->execute([$userId]);
$appointments = $stmt->fetchAll(PDO::FETCH_ASSOC);

$flashMessage = $_SESSION['flash_message'] ?? null;
unset($_SESSION['flash_message']);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Book Appointment - Smart HealthHub</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css">
    <style>
        :root {
            --primary: #4a6fa5;
            --primary-light: #6b8cbc;
            --primary-dark: #2a4a7a;
            --accent: #4cc9f0;
            --accent-dark: #2aa8d0;
            --jelly-blue: #166088;
            --jelly-purple: #4a2d7a;
            --jelly-pink: #d166ff;
            --success: #4ad66d;
            --error: #f72585;
            --warning: #f8961e;
            --dark: #0a1128;
            --light: #f8f9fa;
            --light-gray: #e9ecef;
            --border-radius: 12px;
            --border-radius-lg: 20px;
            --shadow-sm: 0 4px 6px rgba(0, 0, 0, 0.1);
            --shadow-md: 0 8px 15px rgba(0, 0, 0, 0.2);
            --shadow-lg: 0 15px 30px rgba(0, 0, 0, 0.3);
            --transition: all 0.3s cubic-bezier(0.25, 0.8, 0.25, 1);
            --glass-effect: rgba(255, 255, 255, 0.1);
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Poppins', sans-serif;
            background: linear-gradient(135deg, var(--dark), var(--jelly-blue));
            color: var(--light);
            min-height: 100vh;
            line-height: 1.6;
            background-image: 
                radial-gradient(circle at 10% 20%, rgba(22, 96, 136, 0.3) 0%, transparent 20%),
                radial-gradient(circle at 90% 30%, rgba(74, 45, 122, 0.3) 0%, transparent 25%),
                radial-gradient(circle at 30% 80%, rgba(209, 102, 255, 0.2) 0%, transparent 30%);
        }

        .dashboard-container {
            width: 90%;
            max-width: 1200px;
            margin: 30px auto;
            background: rgba(10, 17, 40, 0.85);
            backdrop-filter: blur(10px);
            -webkit-backdrop-filter: blur(10px);
            border-radius: var(--border-radius-lg);
            padding: 30px;
            box-shadow: var(--shadow-lg);
            border: 1px solid rgba(255, 255, 255, 0.1);
            animation: fadeIn 0.8s ease-out;
        }

        h2, h3 {
            font-weight: 700;
            position: relative;
            display: inline-block;
            margin-bottom: 20px;
            background: linear-gradient(90deg, var(--accent), var(--jelly-pink));
            -webkit-background-clip: text;
            background-clip: text;
            color: transparent;
        }

        h2 {
            font-size: 2.2rem;
            margin-bottom: 30px;
        }

        h2::after {
            content: '';
            position: absolute;
            bottom: -8px;
            left: 0;
            width: 60px;
            height: 4px;
            background: linear-gradient(to right, var(--accent), var(--jelly-pink));
            border-radius: 2px;
        }

        h3 {
            font-size: 1.8rem;
            margin-top: 40px;
        }

        .flash-message {
            position: fixed;
            top: 20px;
            left: 50%;
            transform: translateX(-50%);
            padding: 15px 25px;
            border-radius: var(--border-radius);
            display: flex;
            align-items: center;
            gap: 12px;
            z-index: 1000;
            box-shadow: var(--shadow-lg);
            animation: slideInDown 0.5s ease-out;
            opacity: 0;
            transition: opacity 0.3s ease;
        }

        .flash-message.show {
            opacity: 1;
        }

        .flash-success {
            background-color: rgba(74, 214, 109, 0.9);
            color: white;
        }

        .flash-error {
            background-color: rgba(247, 37, 133, 0.9);
            color: white;
        }

        .flash-message i {
            font-size: 1.2rem;
        }

        .booking-form {
            background: rgba(255, 255, 255, 0.05);
            padding: 30px;
            border-radius: var(--border-radius-lg);
            margin-bottom: 40px;
            box-shadow: var(--shadow-md);
            border: 1px solid rgba(255, 255, 255, 0.1);
        }

        .form-group {
            margin-bottom: 20px;
        }

        .form-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: 500;
            color: var(--accent);
        }

        .form-group select, 
        .form-group input {
            width: 100%;
            padding: 12px 15px;
            border-radius: var(--border-radius);
            border: 1px solid rgba(255, 255, 255, 0.2);
            background: rgba(0, 0, 0, 0.3);
            color: var(--light);
            font-family: 'Poppins', sans-serif;
            transition: var(--transition);
        }

        .form-group select:focus, 
        .form-group input:focus {
            outline: none;
            border-color: var(--accent);
            box-shadow: 0 0 0 3px rgba(76, 201, 240, 0.3);
        }

        .btn {
            background: linear-gradient(135deg, var(--accent), var(--jelly-pink));
            color: white;
            border: none;
            padding: 12px 24px;
            border-radius: var(--border-radius);
            font-weight: 600;
            cursor: pointer;
            transition: var(--transition);
            display: inline-flex;
            align-items: center;
            gap: 8px;
            box-shadow: 0 4px 15px rgba(76, 201, 240, 0.3);
        }

        .btn:hover {
            transform: translateY(-3px);
            box-shadow: 0 8px 20px rgba(76, 201, 240, 0.4);
        }

        .appointments-list {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(350px, 1fr));
            gap: 20px;
            margin-top: 20px;
        }

        .appointment-card {
            background: rgba(255, 255, 255, 0.05);
            border-radius: var(--border-radius);
            padding: 20px;
            transition: var(--transition);
            box-shadow: var(--shadow-sm);
            border: 1px solid rgba(255, 255, 255, 0.1);
            position: relative;
            backdrop-filter: blur(5px);
        }

        .appointment-card:hover {
            transform: translateY(-5px);
            box-shadow: var(--shadow-md);
            border-color: rgba(76, 201, 240, 0.3);
        }

        .doctor-name {
            font-size: 1.2rem;
            margin-bottom: 5px;
            color: var(--accent);
        }

        .doctor-specialty {
            display: block;
            font-size: 0.9rem;
            color: rgba(255, 255, 255, 0.7);
            margin-bottom: 15px;
        }

        .appointment-meta {
            display: grid;
            gap: 10px;
        }

        .meta-item {
            display: flex;
            align-items: center;
            gap: 8px;
            font-size: 0.9rem;
            color: rgba(255, 255, 255, 0.8);
        }

        .meta-item i {
            color: var(--accent);
            width: 20px;
            text-align: center;
        }

        .status {
            display: inline-block;
            padding: 3px 8px;
            border-radius: 4px;
            font-size: 0.8rem;
            font-weight: 600;
        }

        .status-pending {
            background-color: rgba(248, 150, 30, 0.2);
            color: var(--warning);
        }

        .status-confirmed {
            background-color: rgba(74, 214, 109, 0.2);
            color: var(--success);
        }

        .status-cancelled {
            background-color: rgba(247, 37, 133, 0.2);
            color: var(--error);
        }

        .no-appointments {
            text-align: center;
            padding: 40px;
            grid-column: 1 / -1;
            color: rgba(255, 255, 255, 0.5);
        }

        .no-appointments i {
            font-size: 3rem;
            margin-bottom: 15px;
            color: var(--accent);
        }

        .no-appointments h4 {
            font-size: 1.3rem;
            margin-bottom: 10px;
            color: var(--light);
        }

        .action-btn {
            padding: 6px 12px;
            border-radius: 6px;
            font-size: 0.8rem;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 5px;
            transition: var(--transition);
            font-weight: 500;
            margin-top: 10px;
        }

        .delete-btn {
            background: rgba(247, 37, 133, 0.2);
            color: var(--error);
            border: 1px solid var(--error);
        }

        .delete-btn:hover {
            background: rgba(247, 37, 133, 0.3);
        }

        /* Animations */
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }

        @keyframes fadeInUp {
            from { opacity: 0; transform: translateY(10px); }
            to { opacity: 1; transform: translateY(0); }
        }

        @keyframes slideInDown {
            from { opacity: 0; transform: translateY(-20px); }
            to { opacity: 1; transform: translateY(0); }
        }

        /* Responsive */
        @media (max-width: 768px) {
            .dashboard-container {
                padding: 20px;
                width: 95%;
            }

            .appointments-list {
                grid-template-columns: 1fr;
            }
            
            .flash-message {
                width: 90%;
                text-align: center;
            }
        }
    </style>
</head>
<body>

<div class="dashboard-container">
    <h2 class="animate_animated animate_fadeInDown"><i class="fas fa-calendar-plus"></i> Book a Doctor Appointment</h2>

    <form method="POST" class="booking-form animate_animated animate_fadeIn">
        <div class="form-group">
            <label for="doctor_id">Select Doctor</label>
            <select name="doctor_id" id="doctor_id" required>
                <option value="">Choose a doctor...</option>
                <?php foreach ($doctors as $doc): ?>
                    <option value="<?= htmlspecialchars($doc['id']) ?>">
                        <?= htmlspecialchars($doc['name']) . " - " . htmlspecialchars($doc['specialty']) ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </div>

        <div class="form-group">
            <label for="date">Appointment Date</label>
            <input type="date" name="date" id="date" required min="<?= date('Y-m-d') ?>">
        </div>

        <div class="form-group">
            <label for="time_slot">Time Slot</label>
            <select name="time_slot" id="time_slot" required>
                <option value="">Select a time slot...</option>
                <option value="9:00 AM - 10:00 AM">9:00 AM - 10:00 AM</option>
                <option value="10:00 AM - 11:00 AM">10:00 AM - 11:00 AM</option>
                <option value="11:00 AM - 12:00 PM">11:00 AM - 12:00 PM</option>
                <option value="2:00 PM - 3:00 PM">2:00 PM - 3:00 PM</option>
                <option value="3:00 PM - 4:00 PM">3:00 PM - 4:00 PM</option>
            </select>
        </div>

        <button type="submit" class="btn">
            <i class="fas fa-calendar-check"></i> Book Appointment
        </button>
    </form>

    <h3 class="animate_animated animate_fadeIn"><i class="fas fa-calendar-alt"></i> Your Upcoming Appointments</h3>
    
    <div class="appointments-list">
        <?php if (count($appointments) > 0): ?>
            <?php foreach ($appointments as $index => $app): ?>
                <div class="appointment-card animate_animated animate_fadeInUp" style="animation-delay: <?= $index * 0.1 ?>s">
                    <h4 class="doctor-name"><?= htmlspecialchars($app['doctor_name']) ?></h4>
                    <span class="doctor-specialty"><?= htmlspecialchars($app['specialty']) ?></span>
                    
                    <div class="appointment-meta">
                        <div class="meta-item">
                            <i class="fas fa-calendar-day"></i>
                            <?= date('F j, Y', strtotime($app['date'])) ?>
                        </div>
                        <div class="meta-item">
                            <i class="fas fa-clock"></i>
                            <?= htmlspecialchars($app['time_slot']) ?>
                        </div>
                        <div class="meta-item">
                            <i class="fas fa-info-circle"></i>
                            <span class="status status-<?= strtolower($app['status']) ?>">
                                <?= htmlspecialchars($app['status']) ?>
                            </span>
                        </div>
                    </div>
                    <a href="?delete_id=<?= $app['id'] ?>" 
                       class="action-btn delete-btn"
                       onclick="return confirm('Are you sure you want to cancel this appointment?')">
                        <i class="fas fa-trash-alt"></i> Cancel Appointment
                    </a>
                </div>
            <?php endforeach; ?>
        <?php else: ?>
            <div class="no-appointments animate_animated animate_fadeIn">
                <i class="far fa-calendar-times"></i>
                <h4>No appointments scheduled yet</h4>
                <p>Book your first appointment using the form above</p>
            </div>
        <?php endif; ?>
    </div>
</div>

<?php if ($flashMessage): ?>
    <div class="flash-message flash-<?= $flashMessage['type'] ?>" id="flash-message">
        <i class="fas fa-<?= $flashMessage['type'] === 'success' ? 'check-circle' : 'exclamation-circle' ?>"></i>
        <span><?= htmlspecialchars($flashMessage['message']) ?></span>
    </div>
<?php endif; ?>

<?php require_once "../includes/footer.php"; ?>

<script>
    // Show flash message and auto-hide after 4 seconds
    const flashMessage = document.getElementById('flash-message');
    if (flashMessage) {
        // Show the message
        setTimeout(() => {
            flashMessage.classList.add('show');
        }, 100);

        // Hide after 4 seconds
        setTimeout(() => {
            flashMessage.style.opacity = '0';
            setTimeout(() => {
                flashMessage.remove();
            }, 300);
        }, 4000);
    }

    // Add animation to elements when they come into view
    const animateOnScroll = () => {
        const elements = document.querySelectorAll('.appointment-card, .booking-form, h2, h3');
        
        elements.forEach(element => {
            const elementPosition = element.getBoundingClientRect().top;
            const screenPosition = window.innerHeight / 1.2;
            
            if (elementPosition < screenPosition) {
                element.classList.add('animate_animated', 'animate_fadeInUp');
            }
        });
    };

    window.addEventListener('scroll', animateOnScroll);
    document.addEventListener('DOMContentLoaded', animateOnScroll);
</script>
</body>
</html>