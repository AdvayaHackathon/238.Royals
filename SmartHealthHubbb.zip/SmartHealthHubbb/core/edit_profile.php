<?php
session_start();
require_once "../config/db.php";
require_once "../includes/auth.php";

$userId = $_SESSION['user_id'];
$success = '';
$error = '';

// Fetch current user data
$stmt = $conn->prepare("SELECT full_name, email, blood_group, date_of_birth FROM users WHERE id = ?");
$stmt->execute([$userId]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $fullName = trim($_POST['full_name'] ?? '');
    $bloodGroup = trim($_POST['blood_group'] ?? '');
    $dateOfBirth = trim($_POST['date_of_birth'] ?? '');

    // Basic validation
    if (empty($fullName)) {
        $error = "Full name is required";
    } else {
        // Update user data
        try {
            $stmt = $conn->prepare("UPDATE users SET full_name = ?, blood_group = ?, date_of_birth = ? WHERE id = ?");
            $stmt->execute([$fullName, $bloodGroup, $dateOfBirth, $userId]);
            
            $_SESSION['user_name'] = $fullName;
            $success = "Profile updated successfully!";
            
            // Update the $user array with new values
            $user['full_name'] = $fullName;
            $user['blood_group'] = $bloodGroup;
            $user['date_of_birth'] = $dateOfBirth;
        } catch (PDOException $e) {
            $error = "Failed to update profile: " . $e->getMessage();
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Profile - Smart HealthHub</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary: #6a4c93;
            --primary-dark: #4a2c7a;
            --primary-light: #8f6cb3;
            --secondary: #3f37c9;
            --accent: #4cc9f0;
            --success: #4ad66d;
            --error: #f72585;
            --warning: #f8961e;
            --light: #f8f9fa;
            --dark: #212529;
            --gray: #6c757d;
            --light-gray: #e9ecef;
            --shadow-sm: 0 1px 3px rgba(0, 0, 0, 0.1);
            --shadow-md: 0 4px 6px rgba(0, 0, 0, 0.15);
            --shadow-lg: 0 10px 25px rgba(0, 0, 0, 0.2);
            --transition: all 0.3s cubic-bezier(0.25, 0.8, 0.25, 1);
            --border-radius: 16px;
            --glass-effect: rgba(255, 255, 255, 0.2);
            --nav-height: 80px;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Poppins', sans-serif;
            background: linear-gradient(135deg, #0f0c29 0%, #302b63 50%, #24243e 100%);
            color: white;
            min-height: 100vh;
            display: flex;
            flex-direction: column;
            line-height: 1.6;
            position: relative;
            overflow-x: hidden;
        }

        /* Navigation */
        .navbar {
            background: rgba(15, 12, 41, 0.8);
            backdrop-filter: blur(10px);
            -webkit-backdrop-filter: blur(10px);
            height: var(--nav-height);
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 0 40px;
            position: fixed;
            width: 100%;
            top: 0;
            z-index: 1000;
            box-shadow: 0 2px 20px rgba(0, 0, 0, 0.3);
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        }

        .logo {
            display: flex;
            align-items: center;
            gap: 10px;
            font-size: 1.5rem;
            font-weight: 700;
            color: white;
            text-decoration: none;
        }

        .logo i {
            color: var(--accent);
        }

        .nav-links {
            display: flex;
            gap: 30px;
        }

        .nav-links a {
            color: white;
            text-decoration: none;
            font-weight: 500;
            position: relative;
            padding: 5px 0;
            transition: var(--transition);
        }

        .nav-links a::after {
            content: '';
            position: absolute;
            bottom: 0;
            left: 0;
            width: 0;
            height: 2px;
            background: linear-gradient(to right, var(--accent), var(--primary-light));
            transition: var(--transition);
        }

        .nav-links a:hover::after {
            width: 100%;
        }

        .nav-links a:hover {
            color: var(--accent);
        }

        .user-menu {
            display: flex;
            align-items: center;
            gap: 20px;
        }

        .user-menu .profile {
            display: flex;
            align-items: center;
            gap: 10px;
            cursor: pointer;
            position: relative;
        }

        .user-menu .profile img {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            object-fit: cover;
            border: 2px solid var(--accent);
        }

        .user-menu .profile-name {
            font-weight: 500;
        }

        .dropdown-menu {
            position: absolute;
            top: 60px;
            right: 0;
            background: rgba(15, 12, 41, 0.95);
            border-radius: var(--border-radius);
            padding: 15px 0;
            min-width: 200px;
            box-shadow: var(--shadow-lg);
            opacity: 0;
            visibility: hidden;
            transform: translateY(10px);
            transition: var(--transition);
            z-index: 1001;
            border: 1px solid rgba(255, 255, 255, 0.1);
        }

        .profile:hover .dropdown-menu {
            opacity: 1;
            visibility: visible;
            transform: translateY(0);
        }

        .dropdown-menu a {
            display: block;
            padding: 10px 20px;
            color: white;
            text-decoration: none;
            transition: var(--transition);
        }

        .dropdown-menu a:hover {
            background: rgba(255, 255, 255, 0.1);
            color: var(--accent);
        }

        .dropdown-menu a i {
            margin-right: 10px;
            width: 20px;
            text-align: center;
        }

        /* Main content */
        .edit-profile-container {
            max-width: 800px;
            margin: calc(var(--nav-height) + 30px) auto 30px;
            padding: 30px;
            flex: 1;
        }

        .edit-profile-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
        }

        .edit-profile-header h2 {
            font-size: 2rem;
            color: white;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .edit-profile-header h2 i {
            color: var(--accent);
        }

        .edit-profile-card {
            background: rgba(255, 255, 255, 0.05);
            backdrop-filter: blur(10px);
            -webkit-backdrop-filter: blur(10px);
            border-radius: var(--border-radius);
            padding: 30px;
            box-shadow: var(--shadow-md);
            border: 1px solid rgba(255, 255, 255, 0.1);
        }

        /* Alerts */
        .alert {
            padding: 15px;
            border-radius: var(--border-radius);
            margin-bottom: 20px;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .alert-success {
            background-color: rgba(74, 214, 109, 0.1);
            color: var(--success);
            border-left: 3px solid var(--success);
        }

        .alert-error {
            background-color: rgba(247, 37, 133, 0.1);
            color: var(--error);
            border-left: 3px solid var(--error);
        }

        /* Form styles */
        .form-group {
            margin-bottom: 20px;
        }

        .form-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: 500;
        }

        .form-control {
            width: 100%;
            padding: 12px 15px;
            background: rgba(255, 255, 255, 0.1);
            border: 1px solid rgba(255, 255, 255, 0.2);
            border-radius: var(--border-radius);
            color: white;
            font-size: 1rem;
            transition: var(--transition);
        }

        .form-control:focus {
            outline: none;
            border-color: var(--accent);
            box-shadow: 0 0 0 3px rgba(76, 201, 240, 0.2);
        }

        select.form-control {
            appearance: none;
            background-image: url("data:image/svg+xml;charset=UTF-8,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='white'%3e%3cpath d='M7 10l5 5 5-5z'/%3e%3c/svg%3e");
            background-repeat: no-repeat;
            background-position: right 15px center;
            background-size: 15px;
        }

        .btn {
            display: inline-block;
            padding: 12px 24px;
            background: linear-gradient(to right, var(--primary), var(--secondary));
            color: white;
            border: none;
            border-radius: var(--border-radius);
            font-size: 1rem;
            font-weight: 600;
            cursor: pointer;
            transition: var(--transition);
            text-align: center;
        }

        .btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 10px rgba(67, 97, 238, 0.3);
        }

        .btn-block {
            display: block;
            width: 100%;
        }

        /* Footer */
        .footer {
            background: rgba(15, 12, 41, 0.8);
            backdrop-filter: blur(10px);
            -webkit-backdrop-filter: blur(10px);
            padding: 20px 0;
            text-align: center;
            color: rgba(255, 255, 255, 0.7);
            font-size: 0.9rem;
            border-top: 1px solid rgba(255, 255, 255, 0.1);
        }

        /* Responsive */
        @media (max-width: 768px) {
            .edit-profile-container {
                padding: 20px;
            }
        }

        @media (max-width: 576px) {
            .edit-profile-card {
                padding: 20px;
            }
        }
    </style>
</head>
<body>
    <!-- Navigation -->
    <nav class="navbar">
        <a href="#" class="logo">
            <i class="fas fa-heartbeat"></i>
            <span>Smart HealthHub</span>
        </a>
        
        <div class="nav-links">
            <a href="dashboard.php"><i class="fas fa-home"></i> Dashboard</a>
            <a href="appointments.php"><i class="fas fa-calendar-alt"></i> Appointments</a>
            <a href="feedback.php"><i class="fas fa-comment-alt"></i> Feedback</a>
            <a href="settings.php"><i class="fas fa-cog"></i> Settings</a>
        </div>
        
        <div class="user-menu">
            <div class="profile">
                <img src="../assets/images/default-profile.jpg" alt="Profile">
                <span class="profile-name"><?= htmlspecialchars($_SESSION['user_name']) ?></span>
                
                <div class="dropdown-menu">
                    <a href="profile.php"><i class="fas fa-user-circle"></i> Profile</a>
                    <a href="orders.php"><i class="fas fa-history"></i> Order History</a>
                    <a href="../includes/logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a>
                </div>
            </div>
        </div>
    </nav>

    <div class="edit-profile-container">
        <div class="edit-profile-header">
            <h2><i class="fas fa-user-edit"></i> Edit Profile</h2>
        </div>
        
        <?php if ($success): ?>
            <div class="alert alert-success">
                <i class="fas fa-check-circle"></i> <?= $success ?>
            </div>
        <?php endif; ?>
        
        <?php if ($error): ?>
            <div class="alert alert-error">
                <i class="fas fa-exclamation-circle"></i> <?= $error ?>
            </div>
        <?php endif; ?>
        
        <div class="edit-profile-card">
            <form method="POST">
                <div class="form-group">
                    <label for="full_name">Full Name</label>
                    <input type="text" id="full_name" name="full_name" class="form-control" 
                           value="<?= htmlspecialchars($user['full_name']) ?>" required>
                </div>
                
                <div class="form-group">
                    <label for="email">Email Address</label>
                    <input type="email" id="email" name="email" class="form-control" 
                           value="<?= htmlspecialchars($user['email']) ?>" readonly>
                </div>
                
                <div class="form-group">
                    <label for="blood_group">Blood Group</label>
                    <select id="blood_group" name="blood_group" class="form-control">
                        <option value="">Select Blood Group</option>
                        <option value="A+" <?= $user['blood_group'] === 'A+' ? 'selected' : '' ?>>A+</option>
                        <option value="A-" <?= $user['blood_group'] === 'A-' ? 'selected' : '' ?>>A-</option>
                        <option value="B+" <?= $user['blood_group'] === 'B+' ? 'selected' : '' ?>>B+</option>
                        <option value="B-" <?= $user['blood_group'] === 'B-' ? 'selected' : '' ?>>B-</option>
                        <option value="AB+" <?= $user['blood_group'] === 'AB+' ? 'selected' : '' ?>>AB+</option>
                        <option value="AB-" <?= $user['blood_group'] === 'AB-' ? 'selected' : '' ?>>AB-</option>
                        <option value="O+" <?= $user['blood_group'] === 'O+' ? 'selected' : '' ?>>O+</option>
                        <option value="O-" <?= $user['blood_group'] === 'O-' ? 'selected' : '' ?>>O-</option>
                    </select>
                </div>
                
                <div class="form-group">
                    <label for="date_of_birth">Date of Birth</label>
                    <input type="date" id="date_of_birth" name="date_of_birth" class="form-control" 
                           value="<?= !empty($user['date_of_birth']) ? htmlspecialchars($user['date_of_birth']) : '' ?>">
                </div>
                
                <button type="submit" class="btn btn-block">Update Profile</button>
            </form>
        </div>
    </div>

    <footer class="footer">
        <p>&copy; <?= date('Y') ?> Smart HealthHub. All rights reserved.</p>
    </footer>
</body>
</html>