<?php
require_once "../includes/auth.php";
require_once "../includes/navbar.php";
?>

<!DOCTYPE html>
<html>
<head>
    <title>Smart HealthBot</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <script src="../assets/js/chatbot.js" defer></script>
    <style>
        #chat-container {
            width: 90%;
            max-width: 600px;
            margin: 20px auto;
            background: #f4f4f4;
            padding: 20px;
            border-radius: 10px;
        }

        #messages {
            height: 300px;
            overflow-y: scroll;
            background: white;
            padding: 10px;
            border: 1px solid #ccc;
            margin-bottom: 10px;
        }

        .message {
            margin-bottom: 10px;
        }

        .user { color: #0077cc; }
        .bot { color: green; }

        .chatbot-button {
  display: inline-block;
  padding: 12px 24px;
  background-color: #4CAF50;
  color: white;
  text-decoration: none;
  font-size: 16px;
  border-radius: 8px;
  transition: background 0.3s;
}

.chatbot-button:hover {
  background-color: #45a049;
}
    </style>
</head>
<body>

<div class="dashboard-container">
    <h2>🤖 Smart HealthBot</h2>
    <div id="chat-container">
        <div id="messages"></div>
        <input type="text" id="userInput" placeholder="Ask me about medicines, health, etc.">
        <button onclick="sendMessage()">Send</button>
    </div>
</div>
<a href="https://poe.com/mr.aidoctor" target="_blank" class="chatbot-button">
  Chat with our Smart AI
</a>

<?php require_once "../includes/footer.php"; ?>
</body>
</html>
