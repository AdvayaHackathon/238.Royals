<?php
session_start();
require_once "../config/db.php";
require_once "../includes/auth.php";

$userId = $_SESSION['user_id'];
$success = '';
$error = '';

// Handle theme toggle
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get current theme preference
    $stmt = $conn->prepare("SELECT theme_preference FROM users WHERE id = ?");
    $stmt->execute([$userId]);
    $currentTheme = $stmt->fetchColumn();
    
    // Toggle theme
    $newTheme = $currentTheme === 'dark' ? 'light' : 'dark';
    
    // Update in database
    $stmt = $conn->prepare("UPDATE users SET theme_preference = ? WHERE id = ?");
    if ($stmt->execute([$newTheme, $userId])) {
        $_SESSION['theme_preference'] = $newTheme;
        $success = "Theme changed to " . ucfirst($newTheme);
    } else {
        $error = "Failed to update theme preference";
    }
}

// Fetch current theme preference
$currentTheme = $_SESSION['theme_preference'] ?? 'light';
?>

<!DOCTYPE html>
<html lang="en">  
<body data-theme="<?= $currentTheme ?>">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Settings - Smart HealthHub</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary: #6a4c93;
            --primary-dark: #4a2c7a;
            --primary-light: #8f6cb3;
            --secondary: #3f37c9;
            --accent: #4cc9f0;
            --success: #4ad66d;
            --error: #f72585;
            --warning: #f8961e;
            --light: #f8f9fa;
            --dark: #212529;
            --gray: #6c757d;
            --light-gray: #e9ecef;
            --shadow-sm: 0 1px 3px rgba(0, 0, 0, 0.1);
            --shadow-md: 0 4px 6px rgba(0, 0, 0, 0.15);
            --shadow-lg: 0 10px 25px rgba(0, 0, 0, 0.2);
            --transition: all 0.3s cubic-bezier(0.25, 0.8, 0.25, 1);
            --border-radius: 16px;
            --glass-effect: rgba(255, 255, 255, 0.2);
            --nav-height: 80px;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Poppins', sans-serif;
            background: linear-gradient(135deg, #0f0c29 0%, #302b63 50%, #24243e 100%);
            color: white;
            min-height: 100vh;
            display: flex;
            flex-direction: column;
            line-height: 1.6;
            position: relative;
            overflow-x: hidden;
        }

        /* Dark theme styles */
        body[data-theme="dark"] {
            background: linear-gradient(135deg, #0a081f 0%, #1a1740 50%, #0f0d1f 100%);
            color: #f0f0f0;
        }

        /* Navigation */
        .navbar {
            background: rgba(15, 12, 41, 0.8);
            backdrop-filter: blur(10px);
            -webkit-backdrop-filter: blur(10px);
            height: var(--nav-height);
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 0 40px;
            position: fixed;
            width: 100%;
            top: 0;
            z-index: 1000;
            box-shadow: 0 2px 20px rgba(0, 0, 0, 0.3);
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        }

        body[data-theme="dark"] .navbar {
            background: rgba(10, 8, 31, 0.9);
        }

        .logo {
            display: flex;
            align-items: center;
            gap: 10px;
            font-size: 1.5rem;
            font-weight: 700;
            color: white;
            text-decoration: none;
        }

        .logo i {
            color: var(--accent);
        }

        .nav-links {
            display: flex;
            gap: 30px;
        }

        .nav-links a {
            color: white;
            text-decoration: none;
            font-weight: 500;
            position: relative;
            padding: 5px 0;
            transition: var(--transition);
        }

        .nav-links a::after {
            content: '';
            position: absolute;
            bottom: 0;
            left: 0;
            width: 0;
            height: 2px;
            background: linear-gradient(to right, var(--accent), var(--primary-light));
            transition: var(--transition);
        }

        .nav-links a:hover::after {
            width: 100%;
        }

        .nav-links a:hover {
            color: var(--accent);
        }

        .user-menu {
            display: flex;
            align-items: center;
            gap: 20px;
        }

        .user-menu .profile {
            display: flex;
            align-items: center;
            gap: 10px;
            cursor: pointer;
            position: relative;
        }

        .user-menu .profile img {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            object-fit: cover;
            border: 2px solid var(--accent);
        }

        .user-menu .profile-name {
            font-weight: 500;
        }

        .dropdown-menu {
            position: absolute;
            top: 60px;
            right: 0;
            background: rgba(15, 12, 41, 0.95);
            border-radius: var(--border-radius);
            padding: 15px 0;
            min-width: 200px;
            box-shadow: var(--shadow-lg);
            opacity: 0;
            visibility: hidden;
            transform: translateY(10px);
            transition: var(--transition);
            z-index: 1001;
            border: 1px solid rgba(255, 255, 255, 0.1);
        }

        body[data-theme="dark"] .dropdown-menu {
            background: rgba(10, 8, 31, 0.95);
        }

        .profile:hover .dropdown-menu {
            opacity: 1;
            visibility: visible;
            transform: translateY(0);
        }

        .dropdown-menu a {
            display: block;
            padding: 10px 20px;
            color: white;
            text-decoration: none;
            transition: var(--transition);
        }

        .dropdown-menu a:hover {
            background: rgba(255, 255, 255, 0.1);
            color: var(--accent);
        }

        .dropdown-menu a i {
            margin-right: 10px;
            width: 20px;
            text-align: center;
        }

        /* Main content */
        .settings-container {
            max-width: 800px;
            margin: calc(var(--nav-height) + 30px) auto 30px;
            padding: 30px;
            flex: 1;
        }

        .settings-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
        }

        .settings-header h2 {
            font-size: 2rem;
            color: white;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .settings-header h2 i {
            color: var(--accent);
        }

        .settings-card {
            background: rgba(255, 255, 255, 0.05);
            backdrop-filter: blur(10px);
            -webkit-backdrop-filter: blur(10px);
            border-radius: var(--border-radius);
            padding: 30px;
            box-shadow: var(--shadow-md);
            border: 1px solid rgba(255, 255, 255, 0.1);
            margin-bottom: 30px;
        }

        body[data-theme="dark"] .settings-card {
            background: rgba(10, 8, 31, 0.3);
        }

        .settings-section {
            margin-bottom: 30px;
        }

        .settings-section h3 {
            color: var(--accent);
            margin-bottom: 20px;
            font-size: 1.3rem;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .settings-option {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 15px 0;
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        }

        .settings-option:last-child {
            border-bottom: none;
        }

        .option-info {
            flex: 1;
        }

        .option-info h4 {
            font-weight: 500;
            margin-bottom: 5px;
        }

        .option-info p {
            font-size: 0.9rem;
            color: rgba(255, 255, 255, 0.7);
        }

        .option-action button {
            background: linear-gradient(to right, var(--primary), var(--secondary));
            color: white;
            border: none;
            border-radius: var(--border-radius);
            padding: 10px 20px;
            cursor: pointer;
            transition: var(--transition);
            font-weight: 500;
        }

        .option-action button:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 10px rgba(67, 97, 238, 0.3);
        }

        .theme-toggle {
            position: relative;
            display: inline-block;
            width: 60px;
            height: 30px;
        }

        .theme-toggle input {
            opacity: 0;
            width: 0;
            height: 0;
        }

        .theme-slider {
            position: absolute;
            cursor: pointer;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background-color: var(--primary-dark);
            transition: var(--transition);
            border-radius: 34px;
        }

        .theme-slider:before {
            position: absolute;
            content: "";
            height: 22px;
            width: 22px;
            left: 4px;
            bottom: 4px;
            background-color: white;
            transition: var(--transition);
            border-radius: 50%;
        }

        input:checked + .theme-slider {
            background-color: var(--primary);
        }

        input:checked + .theme-slider:before {
            transform: translateX(30px);
        }

        .theme-icons {
            position: absolute;
            display: flex;
            justify-content: space-between;
            width: 100%;
            top: 50%;
            transform: translateY(-50%);
            padding: 0 8px;
            pointer-events: none;
        }

        .theme-icons i {
            color: white;
            font-size: 0.8rem;
        }

        /* Alerts */
        .alert {
            padding: 15px;
            border-radius: var(--border-radius);
            margin-bottom: 20px;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .alert-success {
            background-color: rgba(74, 214, 109, 0.1);
            color: var(--success);
            border-left: 3px solid var(--success);
        }

        .alert-error {
            background-color: rgba(247, 37, 133, 0.1);
            color: var(--error);
            border-left: 3px solid var(--error);
        }

        /* Footer */
        .footer {
            background: rgba(15, 12, 41, 0.8);
            backdrop-filter: blur(10px);
            -webkit-backdrop-filter: blur(10px);
            padding: 20px 0;
            text-align: center;
            color: rgba(255, 255, 255, 0.7);
            font-size: 0.9rem;
            border-top: 1px solid rgba(255, 255, 255, 0.1);
        }

        body[data-theme="dark"] .footer {
            background: rgba(10, 8, 31, 0.9);
        }

        /* Responsive */
        @media (max-width: 768px) {
            .settings-container {
                padding: 20px;
            }
            
            .settings-option {
                flex-direction: column;
                align-items: flex-start;
                gap: 15px;
            }
            
            .option-action {
                width: 100%;
            }
            
            .option-action button {
                width: 100%;
            }
        }

        @media (max-width: 576px) {
            .settings-card {
                padding: 20px;
            }
        }
    </style>
</head>
<body>
    <!-- Navigation -->
    <nav class="navbar">
        <a href="#" class="logo">
            <i class="fas fa-heartbeat"></i>
            <span>Smart HealthHub</span>
        </a>
        
        <div class="nav-links">
            <a href="dashboard.php"><i class="fas fa-home"></i> Dashboard</a>
            <a href="appointments.php"><i class="fas fa-calendar-alt"></i> Appointments</a>
            <a href="feedback.php"><i class="fas fa-comment-alt"></i> Feedback</a>
            <a href="settings.php"><i class="fas fa-cog"></i> Settings</a>
        </div>
        
        <div class="user-menu">
            <div class="profile">
                <img src="../assets/images/default-profile.jpg" alt="Profile">
                <span class="profile-name"><?= htmlspecialchars($_SESSION['user_name']) ?></span>
                
                <div class="dropdown-menu">
                    <a href="profile.php"><i class="fas fa-user-circle"></i> Profile</a>
                    <a href="orders.php"><i class="fas fa-history"></i> Order History</a>
                    <a href="../includes/logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a>
                </div>
            </div>
        </div>
    </nav>

    <div class="settings-container">
        <div class="settings-header">
            <h2><i class="fas fa-cog"></i> Settings</h2>
        </div>
        
        <?php if ($success): ?>
            <div class="alert alert-success">
                <i class="fas fa-check-circle"></i> <?= $success ?>
            </div>
        <?php endif; ?>
        
        <?php if ($error): ?>
            <div class="alert alert-error">
                <i class="fas fa-exclamation-circle"></i> <?= $error ?>
            </div>
        <?php endif; ?>
        
        <div class="settings-card">
            <div class="settings-section">
                <h3><i class="fas fa-user-edit"></i> Profile Settings</h3>
                
                <div class="settings-option">
                    <div class="option-info">
                        <h4>Edit Profile Information</h4>
                        <p>Update your personal details, blood group, and date of birth</p>
                    </div>
                    <div class="option-action">
                        <a href="edit_profile.php" class="btn">Edit Profile</a>
                    </div>
                </div>
            </div>
            
            <div class="settings-section">
                <h3><i class="fas fa-palette"></i> Appearance</h3>
                
                <div class="settings-option">
                    <div class="option-info">
                        <h4>Theme Preference</h4>
                        <p>Switch between light and dark mode</p>
                    </div>
                    <div class="option-action">
                        <form method="post">
                            <label class="theme-toggle">
                                <input type="checkbox" name="toggle_theme" onchange="this.form.submit()" <?= $currentTheme === 'dark' ? 'checked' : '' ?>>
                                <span class="theme-slider"></span>
                                <div class="theme-icons">
                                    <i class="fas fa-sun"></i>
                                    <i class="fas fa-moon"></i>
                                </div>
                            </label>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <footer class="footer">
        <p>&copy; <?= date('Y') ?> Smart HealthHub. All rights reserved.</p>
    </footer>
</body>
</html>