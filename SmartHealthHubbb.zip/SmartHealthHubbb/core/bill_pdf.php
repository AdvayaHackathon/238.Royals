<?php
require_once "../config/db.php";
require_once "../includes/auth.php";

// Check if this is a valid checkout session
if (!isset($_SESSION['checkout_total']) || empty($_SESSION['checkout_total'])) {
    header("Location: cart.php");
    exit();
}

$userId = $_SESSION['user_id'];
$total = $_SESSION['checkout_total'];

// Fetch user details
$userStmt = $conn->prepare("SELECT * FROM users WHERE id = ?");
$userStmt->execute([$userId]);
$user = $userStmt->fetch(PDO::FETCH_ASSOC);

// Fetch purchased items
$itemsStmt = $conn->prepare("
    SELECT m.name, m.price, c.quantity, (m.price * c.quantity) as subtotal 
    FROM cart c 
    JOIN medicines m ON c.medicine_id = m.id 
    WHERE c.user_id = ?
");
$itemsStmt->execute([$userId]);
$items = $itemsStmt->fetchAll(PDO::FETCH_ASSOC);

// Include FPDF library
require('../includes/fpdf/fpdf.php');

// Create PDF instance
$pdf = new FPDF();
$pdf->AddPage();
$pdf->SetAutoPageBreak(true, 20);

// Set document information
$pdf->SetTitle('Smart HealthHub - Payment Receipt');
$pdf->SetAuthor('Smart HealthHub');
$pdf->SetCreator('Smart HealthHub System');

// Set colors and fonts
$pdf->SetFillColor(0, 114, 188); // Primary blue
$pdf->SetTextColor(0, 0, 0); // Black text
$pdf->SetFont('Arial', 'B', 16);

// Header
$pdf->Cell(0, 10, 'Smart HealthHub', 0, 1, 'C');
$pdf->SetFont('Arial', 'B', 24);
$pdf->Cell(0, 15, 'PAYMENT RECEIPT', 0, 1, 'C');
$pdf->SetFont('Arial', '', 12);

// Payment status badge
$pdf->SetFillColor(76, 175, 80); // Green
$pdf->SetTextColor(255, 255, 255); // White text
$pdf->Cell(40, 10, 'PAYMENT SUCCESSFUL', 1, 1, 'C', true);
$pdf->Ln(10);
$pdf->SetTextColor(0, 0, 0); // Back to black

// Customer and receipt details
$pdf->SetFont('Arial', 'B', 14);
$pdf->Cell(95, 10, 'Customer Details', 0, 0);
$pdf->Cell(95, 10, 'Receipt Details', 0, 1);
$pdf->SetFont('Arial', '', 12);

// Customer details
$pdf->Cell(95, 7, 'Name: ' . $user['name'], 0, 0);
$pdf->Cell(95, 7, 'Receipt #: SHH' . strtoupper(substr(md5(uniqid()), 0, 8)), 0, 1);
$pdf->Cell(95, 7, 'Email: ' . $user['email'], 0, 0);
$pdf->Cell(95, 7, 'Date: ' . date('F j, Y'), 0, 1);
$pdf->Cell(95, 7, 'Phone: ' . ($user['phone'] ?? 'N/A'), 0, 0);
$pdf->Cell(95, 7, 'Time: ' . date('h:i A'), 0, 1);
$pdf->Ln(10);

// Order summary header
$pdf->SetFont('Arial', 'B', 14);
$pdf->SetFillColor(242, 247, 255); // Light blue
$pdf->Cell(0, 10, 'Order Summary', 0, 1, 'L', true);
$pdf->Ln(5);

// Table headers
$pdf->SetFont('Arial', 'B', 12);
$pdf->Cell(100, 10, 'Item', 1, 0, 'C', true);
$pdf->Cell(30, 10, 'Price', 1, 0, 'C', true);
$pdf->Cell(30, 10, 'Qty', 1, 0, 'C', true);
$pdf->Cell(30, 10, 'Subtotal', 1, 1, 'C', true);
$pdf->SetFont('Arial', '', 12);

// Table rows
foreach ($items as $item) {
    $pdf->Cell(100, 10, $item['name'], 1);
    $pdf->Cell(30, 10, '₹' . number_format($item['price'], 2), 1, 0, 'R');
    $pdf->Cell(30, 10, $item['quantity'], 1, 0, 'C');
    $pdf->Cell(30, 10, '₹' . number_format($item['subtotal'], 2), 1, 1, 'R');
}

// Total row
$pdf->SetFont('Arial', 'B', 12);
$pdf->Cell(160, 10, 'Total:', 1, 0, 'R', true);
$pdf->Cell(30, 10, '₹' . number_format($total, 2), 1, 1, 'R', true);
$pdf->Ln(15);

// Payment method
$pdf->SetFont('Arial', 'B', 14);
$pdf->SetFillColor(242, 247, 255);
$pdf->Cell(0, 10, 'Payment Method', 0, 1, 'L', true);
$pdf->Ln(5);
$pdf->SetFont('Arial', '', 12);
$pdf->Cell(0, 7, 'Credit/Debit Card (Ending with 4242)', 0, 1);
$pdf->Cell(0, 7, 'Authorization Code: ' . strtoupper(substr(md5(uniqid()), 0, 8)), 0, 1);
$pdf->Ln(10);

// Delivery information
$pdf->SetFont('Arial', 'B', 14);
$pdf->SetFillColor(242, 247, 255);
$pdf->Cell(0, 10, 'Delivery Information', 0, 1, 'L', true);
$pdf->Ln(5);
$pdf->SetFont('Arial', '', 12);
$pdf->MultiCell(0, 7, 'Your order will be processed within 24 hours. You will receive a confirmation email with tracking information once your items are shipped.');
$pdf->Ln(15);

// Footer
$pdf->SetFont('Arial', 'I', 10);
$pdf->Cell(0, 7, 'Thank you for shopping with Smart HealthHub!', 0, 1, 'C');
$pdf->Cell(0, 7, 'For any questions, please contact support@smarthealthhub.com', 0, 1, 'C');
$pdf->Cell(0, 7, '© ' . date('Y') . ' Smart HealthHub. All rights reserved.', 0, 1, 'C');

// Clear the cart after generating receipt
$clearCart = $conn->prepare("DELETE FROM cart WHERE user_id = ?");
$clearCart->execute([$userId]);

// Clear checkout session
unset($_SESSION['checkout_total']);

// Output the PDF
$pdf->Output('D', 'SmartHealthHub-Receipt-'.date('Ymd-His').'.pdf');