<?php
require_once "../includes/auth.php";
require_once "../config/db.php";

$userId = $_SESSION['user_id'];

// Calculate cart total
$stmt = $conn->prepare("
    SELECT SUM(m.price * c.quantity) as total 
    FROM cart c 
    JOIN medicines m ON c.medicine_id = m.id 
    WHERE c.user_id = ?
");
$stmt->execute([$userId]);
$total = $stmt->fetchColumn();

if ($total === null || $total <= 0) {
    header("Location: cart.php");
    exit();
}

$_SESSION['checkout_total'] = $total;
header("Location: dummy_payment.php");
exit();
?>