<?php
require_once "../config/db.php";
require_once "../includes/auth.php";

header('Content-Type: text/plain');

$userId = $_SESSION['user_id'];

try {
    $stmt = $conn->prepare("SELECT COUNT(*) FROM cart WHERE user_id = ?");
    $stmt->execute([$userId]);
    echo $stmt->fetchColumn();
} catch (PDOException $e) {
    echo "0";
}