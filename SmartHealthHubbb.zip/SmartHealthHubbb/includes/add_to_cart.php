<?php
require_once "../config/db.php";
require_once "../includes/auth.php";

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Invalid request method']);
    exit();
}

$userId = $_SESSION['user_id'];
$medId = $_POST['medicine_id'];
$qty = $_POST['quantity'];

try {
    // Check stock
    $check = $conn->prepare("SELECT stock FROM medicines WHERE id = ?");
    $check->execute([$medId]);
    $stock = $check->fetchColumn();

    if ($qty > $stock) {
        echo json_encode(['success' => false, 'message' => "Only $stock items left in stock!"]);
        exit();
    }

    // Check if already in cart
    $exists = $conn->prepare("SELECT id, quantity FROM cart WHERE user_id = ? AND medicine_id = ?");
    $exists->execute([$userId, $medId]);
    $existingItem = $exists->fetch(PDO::FETCH_ASSOC);

    if ($existingItem) {
        $newQty = $existingItem['quantity'] + $qty;
        if ($newQty > $stock) {
            echo json_encode(['success' => false, 'message' => "You already have {$existingItem['quantity']} in cart. Only $stock available!"]);
            exit();
        }
        $stmt = $conn->prepare("UPDATE cart SET quantity = ? WHERE id = ?");
        $stmt->execute([$newQty, $existingItem['id']]);
    } else {
        $stmt = $conn->prepare("INSERT INTO cart (user_id, medicine_id, quantity) VALUES (?, ?, ?)");
        $stmt->execute([$userId, $medId, $qty]);
    }

    echo json_encode(['success' => true, 'message' => '✅ Added to cart!']);
} catch (PDOException $e) {
    echo json_encode(['success' => false, 'message' => 'Database error: ' . $e->getMessage()]);
}