<footer class="footer">
  <p>&copy; <?php echo date("Y"); ?> Smart HealthHub. All rights reserved.</p>
</footer>
