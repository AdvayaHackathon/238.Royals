<nav class="navbar">
  <a href="/core/dashboard.php">Dashboard</a>
  <a href="/core/appointments.php">Appointments</a>
  <a href="/core/e-medical.php">e-Medical Store</a>
  <a href="/core/chatbot_page.php">AI Chatbot</a>
  <a href="/core/profile.php">Profile</a>
  <a href="/auth/logout.php">Logout</a>
</nav>
