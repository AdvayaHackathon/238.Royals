<?php
session_start();
require_once "../config/db.php";

if (!isset($_SESSION['admin_id'])) {
    header("Location: admin_login.php");
    exit;
}

// Handle delete action
if (isset($_GET['delete_id'])) {
    $deleteId = $_GET['delete_id'];
    try {
        $stmt = $conn->prepare("DELETE FROM appointments WHERE id = ?");
        $stmt->execute([$deleteId]);

        $_SESSION['flash_message'] = [
            'type' => 'success',
            'message' => 'Appointment deleted successfully!'
        ];
        header("Location: manage_appointments.php");
        exit;
    } catch (PDOException $e) {
        $_SESSION['flash_message'] = [
            'type' => 'error',
            'message' => 'Error deleting appointment: ' . $e->getMessage()
        ];
        header("Location: manage_appointments.php");
        exit;
    }
}

// Fetch appointments
$appointments = $conn->query("
    SELECT a.*, u.full_name AS patient_name, d.name AS doctor_name 
    FROM appointments a
    JOIN users u ON a.user_id = u.id
    JOIN doctors d ON a.doctor_id = d.id
    ORDER BY a.date DESC
")->fetchAll();

$flashMessage = $_SESSION['flash_message'] ?? null;
unset($_SESSION['flash_message']);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Manage Appointments - Smart HealthHub</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css">
    <style>
        :root {
            --primary: #6a4c93;
            --primary-light: #8f6cb3;
            --primary-dark: #4a2d7a;
            --accent: #4cc9f0;
            --accent-dark: #2aa8d0;
            --success: #4ad66d;
            --error: #f72585;
            --warning: #f8961e;
            --dark: #212529;
            --light-gray: #e9ecef;
            --border-radius: 12px;
            --shadow-sm: 0 4px 6px rgba(0, 0, 0, 0.1);
            --shadow-md: 0 8px 15px rgba(0, 0, 0, 0.2);
            --shadow-lg: 0 15px 30px rgba(0, 0, 0, 0.3);
            --transition: all 0.3s cubic-bezier(0.25, 0.8, 0.25, 1);
            --glass-effect: rgba(255, 255, 255, 0.1);
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Poppins', sans-serif;
            background: linear-gradient(135deg, #0f0c29, #302b63, #24243e);
            color: white;
            min-height: 100vh;
            line-height: 1.6;
        }

        .dashboard-container {
            width: 90%;
            max-width: 1200px;
            margin: 30px auto;
            background: rgba(15, 12, 41, 0.8);
            backdrop-filter: blur(10px);
            -webkit-backdrop-filter: blur(10px);
            border-radius: var(--border-radius);
            padding: 30px;
            box-shadow: var(--shadow-lg);
            border: 1px solid rgba(255, 255, 255, 0.1);
            animation: fadeIn 0.8s ease-out;
        }

        h2 {
            font-size: 2rem;
            font-weight: 700;
            margin-bottom: 20px;
            position: relative;
            display: inline-block;
        }

        h2::after {
            content: '';
            position: absolute;
            bottom: -8px;
            left: 0;
            width: 60px;
            height: 4px;
            background: linear-gradient(to right, var(--accent), var(--primary-light));
            border-radius: 2px;
        }

        .flash-message {
            padding: 15px;
            border-radius: var(--border-radius);
            margin-bottom: 25px;
            display: flex;
            align-items: center;
            gap: 12px;
            animation: slideInDown 0.5s ease-out;
        }

        .flash-success {
            background-color: rgba(74, 214, 109, 0.15);
            border-left: 4px solid var(--success);
        }

        .flash-error {
            background-color: rgba(247, 37, 133, 0.15);
            border-left: 4px solid var(--error);
        }

        .flash-message i {
            font-size: 1.2rem;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            border-radius: var(--border-radius);
            overflow: hidden;
            animation: fadeIn 0.8s ease-out;
            margin: 25px 0;
        }

        th, td {
            padding: 14px 16px;
            text-align: left;
            transition: var(--transition);
        }

        th {
            background: linear-gradient(135deg, var(--primary), var(--primary-dark));
            font-weight: 600;
            text-transform: uppercase;
            font-size: 0.85rem;
            letter-spacing: 0.5px;
            color: white;
        }

        td {
            background: rgba(255, 255, 255, 0.03);
            border-bottom: 1px solid rgba(255, 255, 255, 0.05);
        }

        tr:hover td {
            background: rgba(255, 255, 255, 0.08);
            transform: translateY(-1px);
        }

        tr {
            transition: var(--transition);
            animation: fadeInUp 0.5s ease-out forwards;
            opacity: 0;
        }

      

        .action-btn {
            padding: 8px 16px;
            border-radius: var(--border-radius);
            font-size: 0.85rem;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            transition: var(--transition);
            font-weight: 500;
            border: none;
            cursor: pointer;
        }

        .delete-btn {
            background: linear-gradient(135deg, var(--error), #d31660);
            color: white;
            box-shadow: 0 4px 12px rgba(247, 37, 133, 0.3);
        }

        .delete-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 16px rgba(247, 37, 133, 0.4);
        }

        .edit-btn {
            background: linear-gradient(135deg, var(--accent), var(--accent-dark));
            color: white;
            box-shadow: 0 4px 12px rgba(76, 201, 240, 0.3);
            margin-right: 8px;
        }

        .edit-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 16px rgba(76, 201, 240, 0.4);
        }

        .back-link {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            margin-top: 25px;
            color: var(--accent);
            text-decoration: none;
            font-weight: 500;
            transition: var(--transition);
            padding: 8px 16px;
            border-radius: var(--border-radius);
            background: rgba(76, 201, 240, 0.1);
        }

        .back-link:hover {
            background: rgba(76, 201, 240, 0.2);
            transform: translateX(-3px);
        }

        .action-buttons {
            display: flex;
            gap: 8px;
        }

        /* Search and filter section */
        .search-filter {
            display: flex;
            gap: 15px;
            margin-bottom: 25px;
            flex-wrap: wrap;
        }

        .search-box, .filter-select {
            flex: 1;
            min-width: 200px;
        }

        .search-box input, .filter-select select {
            width: 100%;
            padding: 12px 15px;
            border-radius: var(--border-radius);
            border: none;
            background: rgba(255, 255, 255, 0.1);
            color: white;
            font-family: 'Poppins', sans-serif;
            transition: var(--transition);
        }

        .search-box input:focus, .filter-select select:focus {
            outline: none;
            background: rgba(255, 255, 255, 0.15);
            box-shadow: 0 0 0 2px var(--accent);
        }

        .filter-select select {
            appearance: none;
            background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='16' height='16' fill='white' viewBox='0 0 16 16'%3E%3Cpath d='M7.247 11.14 2.451 5.658C1.885 5.013 2.345 4 3.204 4h9.592a1 1 0 0 1 .753 1.659l-4.796 5.48a1 1 0 0 1-1.506 0z'/%3E%3C/svg%3E");
            background-repeat: no-repeat;
            background-position: right 15px center;
            background-size: 12px;
        }

        /* Animations */
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }

        @keyframes fadeInUp {
            from { opacity: 0; transform: translateY(10px); }
            to { opacity: 1; transform: translateY(0); }
        }

        @keyframes slideInDown {
            from { opacity: 0; transform: translateY(-20px); }
            to { opacity: 1; transform: translateY(0); }
        }

        /* Responsive */
        @media (max-width: 768px) {
            .dashboard-container {
                padding: 20px;
                width: 95%;
            }

            table {
                display: block;
                overflow-x: auto;
                white-space: nowrap;
            }

            .action-buttons {
                flex-direction: column;
            }

            .edit-btn, .delete-btn {
                width: 100%;
                justify-content: center;
            }
        }
    </style>
</head>
<body>

<div class="dashboard-container">
    <h2 class="animate__animated animate__fadeInDown"><i class="fas fa-calendar-check"></i> Manage Appointments</h2>

    <?php if ($flashMessage): ?>
        <div class="flash-message flash-<?= $flashMessage['type'] ?> animate__animated animate__slideInDown">
            <i class="fas fa-<?= $flashMessage['type'] === 'success' ? 'check-circle' : 'exclamation-circle' ?>"></i>
            <?= htmlspecialchars($flashMessage['message']) ?>
        </div>
    <?php endif; ?>

    <!-- Search Only -->
    <div class="search-filter animate__animated animate__fadeIn">
        <div class="search-box" style="flex: 1;">
            <input type="text" id="searchInput" placeholder="Search appointments...">
        </div>
    </div>

    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Patient</th>
                <th>Doctor</th>
                <th>Date</th>
                <th>Time</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($appointments as $index => $a): ?>
            <tr style="animation-delay: <?= 0.1 * $index ?>s;">
                <td><?= $a['id'] ?></td>
                <td><?= htmlspecialchars($a['patient_name']) ?></td>
                <td><?= htmlspecialchars($a['doctor_name']) ?></td>
                <td><?= date('M j, Y', strtotime($a['date'])) ?></td>
                <td><?= $a['time_slot'] ?></td>
                <td>
                    <div class="action-buttons">
                        <a href="?delete_id=<?= $a['id'] ?>" 
                           class="action-btn delete-btn"
                           onclick="return confirmDelete(event)">
                            <i class="fas fa-trash-alt"></i> Delete
                        </a>
                    </div>
                </td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>

    <a href="admin_dashboard.php" class="back-link animate__animated animate__fadeIn">
        <i class="fas fa-arrow-left"></i> Back to Dashboard
    </a>
</div>

<script>
    // Delete confirmation
    function confirmDelete(event) {
        event.preventDefault();
        const deleteUrl = event.currentTarget.getAttribute('href');

        Swal.fire({
            title: 'Are you sure?',
            text: "You won't be able to revert this!",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#f72585',
            cancelButtonColor: '#6c757d',
            confirmButtonText: 'Yes, delete it!',
            background: 'rgba(15, 12, 41, 0.95)',
            backdrop: `
                rgba(0,0,0,0.8)
                url("/images/nyan-cat.gif")
                left top
                no-repeat
            `
        }).then((result) => {
            if (result.isConfirmed) {
                window.location.href = deleteUrl;
            }
        });

        return false;
    }

    // Search appointments
    document.getElementById('searchInput').addEventListener('input', function() {
        const searchValue = this.value.toLowerCase();
        const rows = document.querySelectorAll('tbody tr');

        rows.forEach(row => {
            const rowText = row.textContent.toLowerCase();
            row.style.display = rowText.includes(searchValue) ? '' : 'none';
        });
    });

    // Scroll animation
    const animateOnScroll = () => {
        const elements = document.querySelectorAll('tr');
        elements.forEach(element => {
            const elementPosition = element.getBoundingClientRect().top;
            const screenPosition = window.innerHeight / 1.2;
            if (elementPosition < screenPosition) {
                element.classList.add('animate__animated', 'animate__fadeInUp');
            }
        });
    };

    window.addEventListener('scroll', animateOnScroll);
    document.addEventListener('DOMContentLoaded', animateOnScroll);
</script>

<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

</body>
</html>
