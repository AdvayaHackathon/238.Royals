<?php
// Enable error reporting for debugging
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

session_start();
require_once "../config/db.php"; // Ensure this contains your PDO $conn setup

$error = "";

// Handle login
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = $_POST['email'] ?? '';
    $password = $_POST['password'] ?? '';

    if (!empty($email) && !empty($password)) {
        $hashedPassword = md5($password); // Consider switching to password_hash for security

        $stmt = $conn->prepare("SELECT * FROM admins WHERE email = ? AND password = ?");
        $stmt->execute([$email, $hashedPassword]);
        $admin = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($admin) {
            $_SESSION['admin_id'] = $admin['id'];
            header("Location: admin_dashboard.php");
            exit;
        } else {
            $error = "❌ Invalid credentials!";
        }
    } else {
        $error = "❗ Please fill in all fields.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Admin Login - Smart HealthHub</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600&display=swap" rel="stylesheet">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Poppins', sans-serif;
            height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            background: linear-gradient(120deg, #0f0c29, #302b63, #24243e);
            overflow: hidden;
        }

        .login-container {
            background: rgba(255, 255, 255, 0.05);
            border: 1px solid rgba(255, 255, 255, 0.1);
            padding: 40px;
            border-radius: 20px;
            width: 90%;
            max-width: 350px;
            box-shadow: 0 8px 30px rgba(0, 0, 0, 0.25);
            backdrop-filter: blur(10px);
            -webkit-backdrop-filter: blur(10px);
            animation: fadeIn 0.8s ease;
        }

        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }

        .login-container h2 {
            text-align: center;
            color: #ffffff;
            margin-bottom: 25px;
            font-size: 1.8rem;
        }

        .login-container input {
            width: 100%;
            padding: 12px 15px;
            margin-bottom: 18px;
            border: none;
            border-radius: 12px;
            background-color: rgba(255, 255, 255, 0.07);
            color: #fff;
            font-size: 1rem;
            outline: none;
            transition: background 0.3s ease;
        }

        .login-container input::placeholder {
            color: rgba(255, 255, 255, 0.5);
        }

        .login-container input:focus {
            background-color: rgba(255, 255, 255, 0.12);
        }

        .login-container button {
            width: 100%;
            padding: 12px;
            background: linear-gradient(135deg, #4cc9f0, #9b5de5);
            border: none;
            border-radius: 12px;
            color: #fff;
            font-weight: 600;
            cursor: pointer;
            font-size: 1rem;
            transition: transform 0.2s ease, box-shadow 0.3s ease;
        }

        .login-container button:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 20px rgba(155, 93, 229, 0.4);
        }

        .login-container p.error {
            color: #ff6b6b;
            font-size: 0.9rem;
            margin-top: 10px;
            text-align: center;
        }

        @media (max-width: 400px) {
            .login-container {
                padding: 30px 20px;
            }

            .login-container h2 {
                font-size: 1.5rem;
            }
        }
    </style>
</head>
<body>

<div class="login-container">
    <form method="POST">
        <h2>🔒 Admin Login</h2>
        <input type="email" name="email" placeholder="Admin Email" required>
        <input type="password" name="password" placeholder="Password" required>
        <button type="submit">Sign In</button>
        <?php if (!empty($error)) echo "<p class='error'>$error</p>"; ?>
    </form>
</div>

</body>
</html>