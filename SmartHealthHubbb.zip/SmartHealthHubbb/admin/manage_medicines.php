<?php
session_start();
require_once "../config/db.php";
if (!isset($_SESSION['admin_id'])) {
    header("Location: admin_login.php");
    exit;
}

// Add new medicine
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $_POST['name'];
    $desc = $_POST['description'];
    $price = $_POST['price'];
    $stock = $_POST['stock'];

    $stmt = $conn->prepare("INSERT INTO medicines (name, description, price, stock) VALUES (?, ?, ?, ?)");
    $stmt->execute([$name, $desc, $price, $stock]);
}

// Fetch all medicines
$meds = $conn->query("SELECT * FROM medicines")->fetchAll();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Manage Medicines - Smart HealthHub</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600&display=swap" rel="stylesheet">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Poppins', sans-serif;
            background: linear-gradient(120deg, #0f0c29, #302b63, #24243e);
            color: #fff;
            padding: 40px 20px;
            min-height: 100vh;
        }

        .container {
            max-width: 800px;
            margin: auto;
            background: rgba(255, 255, 255, 0.05);
            border: 1px solid rgba(255, 255, 255, 0.1);
            border-radius: 20px;
            padding: 30px;
            backdrop-filter: blur(10px);
            -webkit-backdrop-filter: blur(10px);
            box-shadow: 0 8px 30px rgba(0, 0, 0, 0.25);
            animation: fadeIn 0.8s ease;
        }

        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }

        h2, h3 {
            text-align: center;
            margin-bottom: 20px;
        }

        form {
            display: flex;
            flex-direction: column;
            gap: 15px;
            margin-bottom: 30px;
        }

        input, button {
            padding: 12px 15px;
            border: none;
            border-radius: 10px;
            font-size: 1rem;
            font-family: inherit;
        }

        input {
            background-color: rgba(255, 255, 255, 0.08);
            color: white;
        }

        input::placeholder {
            color: rgba(255, 255, 255, 0.5);
        }

        button {
            background: linear-gradient(135deg, #4cc9f0, #9b5de5);
            color: white;
            font-weight: 600;
            cursor: pointer;
            transition: 0.3s ease;
        }

        button:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 20px rgba(155, 93, 229, 0.4);
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
            background: rgba(255, 255, 255, 0.04);
            border-radius: 10px;
            overflow: hidden;
        }

        table th, table td {
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        }

        table th {
            background-color: rgba(255, 255, 255, 0.1);
        }

        @media (max-width: 600px) {
            .container {
                padding: 20px;
            }

            table, thead, tbody, th, td, tr {
                display: block;
            }

            tr {
                margin-bottom: 15px;
            }

            td {
                position: relative;
                padding-left: 50%;
            }

            td::before {
                content: attr(data-label);
                position: absolute;
                left: 0;
                width: 45%;
                padding-left: 10px;
                font-weight: bold;
                color: #ccc;
            }

            table th {
                display: none;
            }
        }
    </style>
</head>
<body>

<div class="container">
    <h2>💊 Manage Medicines</h2>

    <form method="POST">
        <input type="text" name="name" placeholder="Medicine Name" required>
        <input type="text" name="description" placeholder="Description">
        <input type="number" name="price" placeholder="Price (₹)" step="0.01" required>
        <input type="number" name="stock" placeholder="Stock" required>
        <button type="submit">Add Medicine</button>
    </form>

    <h3>📋 All Medicines</h3>
    <table>
        <thead>
            <tr>
                <th>ID</th><th>Name</th><th>Price</th><th>Stock</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($meds as $med): ?>
                <tr>
                    <td data-label="ID"><?= $med['id'] ?></td>
                    <td data-label="Name"><?= htmlspecialchars($med['name']) ?></td>
                    <td data-label="Price">₹<?= number_format($med['price'], 2) ?></td>
                    <td data-label="Stock"><?= $med['stock'] ?></td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>

</body>
</html>