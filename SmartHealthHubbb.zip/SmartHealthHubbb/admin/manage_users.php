<?php
require_once "../config/db.php";
session_start();

// Check admin authentication
if (!isset($_SESSION['admin_id'])) {
    header("Location: admin_login.php");
    exit;
}

$stmt = $conn->query("SELECT * FROM users");
$users = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Users - Smart HealthHub</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        /* Add your styles here */
        :root {
            --primary: #6a4c93;
            --primary-dark: #4a2c7a;
            --primary-light: #8f6cb3;
            --secondary: #3f37c9;
            --accent: #4cc9f0;
            --success: #4ad66d;
            --error: #f72585;
            --warning: #f8961e;
            --light: #f8f9fa;
            --dark: #212529;
            --gray: #6c757d;
            --light-gray: #e9ecef;
            --shadow-sm: 0 1px 3px rgba(0, 0, 0, 0.1);
            --shadow-md: 0 4px 6px rgba(0, 0, 0, 0.15);
            --shadow-lg: 0 10px 25px rgba(0, 0, 0, 0.2);
            --transition: all 0.3s cubic-bezier(0.25, 0.8, 0.25, 1);
            --border-radius: 12px;
            --glass-effect: rgba(255, 255, 255, 0.2);
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Poppins', sans-serif;
            background: linear-gradient(135deg, #0f0c29 0%, #302b63 50%, #24243e 100%);
            color: white;
            min-height: 100vh;
            line-height: 1.6;
        }

        .admin-container {
            width: 90%;
            max-width: 1200px;
            margin: 30px auto;
            background: rgba(255, 255, 255, 0.05);
            backdrop-filter: blur(10px);
            -webkit-backdrop-filter: blur(10px);
            border-radius: var(--border-radius);
            padding: 30px;
            box-shadow: var(--shadow-lg);
            border: 1px solid rgba(255, 255, 255, 0.1);
            animation: fadeIn 0.8s ease-out;
        }

        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }

        h2 {
            color: white;
            margin-bottom: 20px;
            font-weight: 700;
            font-size: 2rem;
            position: relative;
            display: inline-block;
        }

        h2::after {
            content: '';
            position: absolute;
            bottom: -8px;
            left: 0;
            width: 50px;
            height: 4px;
            background: linear-gradient(to right, var(--accent), var(--primary-light));
            border-radius: 2px;
        }

        .users-table {
            width: 100%;
            border-collapse: separate;
            border-spacing: 0;
            margin-top: 20px;
            overflow: hidden;
            border-radius: var(--border-radius);
            animation: slideIn 0.5s ease-out;
        }

        @keyframes slideIn {
            from { opacity: 0; transform: translateX(-20px); }
            to { opacity: 1; transform: translateX(0); }
        }

        .users-table th {
            background: rgba(106, 76, 147, 0.5);
            color: white;
            padding: 15px;
            text-align: left;
            font-weight: 600;
        }

        .users-table td {
            padding: 12px 15px;
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
            background: rgba(255, 255, 255, 0.05);
        }

        .users-table tr:last-child td {
            border-bottom: none;
        }

        .users-table tr:hover td {
            background: rgba(255, 255, 255, 0.1);
            transform: scale(1.01);
        }

        .users-table tr {
            transition: var(--transition);
        }

        .action-btn {
            color: white;
            text-decoration: none;
            padding: 6px 12px;
            border-radius: var(--border-radius);
            font-size: 0.9rem;
            transition: var(--transition);
            display: inline-flex;
            align-items: center;
            gap: 5px;
        }

        .delete-btn {
            background: rgba(247, 37, 133, 0.2);
            border: 1px solid var(--error);
        }

        .delete-btn:hover {
            background: rgba(247, 37, 133, 0.4);
            transform: translateY(-2px);
        }

        .back-link {
            display: inline-block;
            margin-top: 20px;
            color: var(--accent);
            text-decoration: none;
            font-weight: 500;
            transition: var(--transition);
        }

        .back-link:hover {
            text-decoration: underline;
            transform: translateX(-3px);
        }

        /* Responsive */
        @media (max-width: 768px) {
            .admin-container {
                padding: 20px;
                width: 95%;
            }
            
            .users-table {
                display: block;
                overflow-x: auto;
            }
            
            h2 {
                font-size: 1.6rem;
            }
        }

        /* Row animation */
        @keyframes fadeInRow {
            from { opacity: 0; transform: translateY(10px); }
            to { opacity: 1; transform: translateY(0); }
        }

        .users-table tr {
            animation: fadeInRow 0.5s ease-out forwards;
            opacity: 0;
        }

        .users-table tr:nth-child(1) { animation-delay: 0.1s; }
        .users-table tr:nth-child(2) { animation-delay: 0.2s; }
        .users-table tr:nth-child(3) { animation-delay: 0.3s; }
        .users-table tr:nth-child(4) { animation-delay: 0.4s; }
        .users-table tr:nth-child(5) { animation-delay: 0.5s; }
        .users-table tr:nth-child(6) { animation-delay: 0.6s; }
        .users-table tr:nth-child(7) { animation-delay: 0.7s; }
        .users-table tr:nth-child(8) { animation-delay: 0.8s; }
        .users-table tr:nth-child(9) { animation-delay: 0.9s; }
        .users-table tr:nth-child(10) { animation-delay: 1.0s; }
    </style>
</head>
<body>
    <div class="admin-container">
        <h2><i class="fas fa-users"></i> All Users</h2>
        
        <table class="users-table">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Full Name</th>
                    <th>Email</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($users as $user): ?>
                <tr>
                    <td><?= htmlspecialchars($user['id']); ?></td>
                    <td><?= htmlspecialchars($user['full_name']); ?></td> <!-- Updated to use 'full_name' -->
                    <td><?= htmlspecialchars($user['email']); ?></td>
                    <td>
                        <a href="delete_user.php?id=<?= $user['id']; ?>" 
                           class="action-btn delete-btn"
                           onclick="return confirm('Are you sure you want to delete this user?')">
                            <i class="fas fa-trash-alt"></i> Delete
                        </a>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        
        <a href="admin_dashboard.php" class="back-link">
            <i class="fas fa-arrow-left"></i> Back to Dashboard
        </a>
    </div>

    <script>
        // Enhanced confirmation for delete
        document.querySelectorAll('.delete-btn').forEach(btn => {
            btn.addEventListener('click', function(e) {
                if (!confirm('Are you sure you want to delete this user? This action cannot be undone.')) {
                    e.preventDefault();
                }
            });
        });
    </script>
</body>
</html>