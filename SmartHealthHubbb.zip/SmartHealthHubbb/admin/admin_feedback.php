<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once "../includes/admin_auth.php";
require_once "../config/db.php";

try {
    $stmt = $conn->query("
        SELECT f.*, u.full_name, u.email 
        FROM feedbacks f
        JOIN users u ON f.user_id = u.id
        ORDER BY f.created_at DESC
    ");
    $feedbacks = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    die("Error fetching feedbacks: " . $e->getMessage());
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Admin - Manage Feedbacks</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">

    <style>
        /* [STYLE OMITTED FOR BREVITY — KEEP YOUR EXISTING CSS HERE] */
        
        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }

        body {
            font-family: 'Poppins', sans-serif;
            background: linear-gradient(120deg, #0f0c29, #302b63, #24243e);
            color: #fff;
            min-height: 100vh;
            padding: 40px 20px;
        }

        .container {
            max-width: 1100px;
            margin: auto;
            background: rgba(255, 255, 255, 0.05);
            border: 1px solid rgba(255, 255, 255, 0.1);
            border-radius: 20px;
            padding: 30px;
            backdrop-filter: blur(10px);
            -webkit-backdrop-filter: blur(10px);
            box-shadow: 0 8px 30px rgba(0, 0, 0, 0.25);
            animation: fadeIn 0.8s ease;
        }

        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }

        h1 {
            font-size: 2rem;
            margin-bottom: 25px;
            text-align: center;
            color: #fff;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
            border-radius: 10px;
            overflow: hidden;
            background: rgba(255, 255, 255, 0.04);
        }

        th, td {
            padding: 12px 15px;
            border-bottom: 1px solid rgba(255, 255, 255, 0.08);
            font-size: 0.95rem;
        }

        th {
            background-color: rgba(255, 255, 255, 0.1);
            color: #eee;
            text-align: left;
        }

        td {
            color: #eee;
        }

        .tag {
            display: inline-block;
            padding: 4px 10px;
            border-radius: 6px;
            font-size: 0.8rem;
            font-weight: 600;
            color: #fff;
        }

        .tag.doctor { background-color: #9b5de5; }
        .tag.website { background-color: #3f37c9; }

        .rating-stars {
            color: #fbc02d;
            font-size: 1.1rem;
        }

        .no-feedback {
            text-align: center;
            padding: 40px 0;
            font-size: 1.1rem;
            color: #bbb;
        }

        @media (max-width: 768px) {
            table, thead, tbody, th, td, tr {
                display: block;
            }

            thead tr {
                display: none;
            }

            td {
                position: relative;
                padding-left: 50%;
                border: none;
                border-bottom: 1px solid rgba(255,255,255,0.1);
            }

            td::before {
                position: absolute;
                top: 10px;
                left: 15px;
                width: 45%;
                white-space: nowrap;
                font-weight: bold;
                color: #ccc;
            }

            td:nth-of-type(1)::before { content: "User"; }
            td:nth-of-type(2)::before { content: "Email"; }
            td:nth-of-type(3)::before { content: "Type"; }
            td:nth-of-type(4)::before { content: "Doctor"; }
            td:nth-of-type(5)::before { content: "Rating"; }
            td:nth-of-type(6)::before { content: "Message"; }
            td:nth-of-type(7)::before { content: "Submitted"; }
        }

    </style>
</head>
<body>
    <div class="container">
        <h1>💬 All User Feedbacks</h1>

        <?php if (count($feedbacks) > 0): ?>
            <table>
                <thead>
                    <tr>
                        <th>User</th>
                        <th>Email</th>
                        <th>Type</th>
                        <th>Doctor</th>
                        <th>Rating</th>
                        <th>Message</th>
                        <th>Submitted</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($feedbacks as $feedback): ?>
                        <tr>
                            <td><?= htmlspecialchars($feedback['full_name']) ?></td>
                            <td><?= htmlspecialchars($feedback['email']) ?></td>
                            <td><span class="tag <?= $feedback['type'] ?>"><?= ucfirst($feedback['type']) ?></span></td>
                            <td>
                                <?= $feedback['type'] === 'doctor'
                                    ? htmlspecialchars($feedback['doctor_name'] ?? '-')
                                    : '-' ?>
                            </td>
                            <td class="rating-stars"><?= str_repeat("★", (int)$feedback['rating']) ?></td>
                            <td><?= nl2br(htmlspecialchars($feedback['message'])) ?></td>
                            <td><?= date("d M Y, H:i", strtotime($feedback['created_at'])) ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php else: ?>
            <div class="no-feedback">No feedbacks have been submitted yet.</div>
        <?php endif; ?>
    </div>
</body>
</html>
