<?php
session_start();
if (!isset($_SESSION['admin_id'])) {
    header("Location: admin_login.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - Smart HealthHub</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary: #6a4c93;
            --primary-dark: #4a2c7a;
            --primary-light: #8f6cb3;
            --secondary: #3f37c9;
            --accent: #4cc9f0;
            --success: #4ad66d;
            --error: #f72585;
            --warning: #f8961e;
            --light: #f8f9fa;
            --dark: #212529;
            --gray: #6c757d;
            --light-gray: #e9ecef;
            --shadow-sm: 0 1px 3px rgba(0, 0, 0, 0.1);
            --shadow-md: 0 4px 6px rgba(0, 0, 0, 0.15);
            --shadow-lg: 0 10px 25px rgba(0, 0, 0, 0.2);
            --transition: all 0.3s cubic-bezier(0.25, 0.8, 0.25, 1);
            --border-radius: 12px;
            --glass-effect: rgba(255, 255, 255, 0.2);
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Poppins', sans-serif;
            background: linear-gradient(135deg, #0f0c29 0%, #302b63 50%, #24243e 100%);
            color: white;
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            line-height: 1.6;
        }

        .admin-container {
            width: 90%;
            max-width: 1200px;
            background: rgba(255, 255, 255, 0.05);
            backdrop-filter: blur(10px);
            -webkit-backdrop-filter: blur(10px);
            border-radius: var(--border-radius);
            padding: 40px;
            box-shadow: var(--shadow-lg);
            border: 1px solid rgba(255, 255, 255, 0.1);
            animation: fadeIn 0.8s ease-out;
        }

        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }

        h2 {
            color: white;
            margin-bottom: 30px;
            font-weight: 700;
            font-size: 2.2rem;
            position: relative;
            display: inline-block;
        }

        h2::after {
            content: '';
            position: absolute;
            bottom: -8px;
            left: 0;
            width: 50px;
            height: 4px;
            background: linear-gradient(to right, var(--accent), var(--primary-light));
            border-radius: 2px;
        }

        .admin-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
            gap: 20px;
            margin-top: 30px;
        }

        .admin-card {
            background: rgba(255, 255, 255, 0.1);
            border-radius: var(--border-radius);
            padding: 25px;
            display: flex;
            flex-direction: column;
            align-items: flex-start;
            transition: var(--transition);
            border: 1px solid rgba(255, 255, 255, 0.1);
            position: relative;
            overflow: hidden;
        }

        .admin-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: linear-gradient(135deg, rgba(106, 76, 147, 0.1) 0%, transparent 70%);
            z-index: -1;
        }

        .admin-card:hover {
            transform: translateY(-5px);
            box-shadow: var(--shadow-lg);
            background: rgba(255, 255, 255, 0.15);
            border-color: var(--accent);
        }

        .admin-card i {
            font-size: 1.8rem;
            margin-bottom: 15px;
            color: var(--accent);
            background: rgba(76, 201, 240, 0.1);
            width: 60px;
            height: 60px;
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: 50%;
        }

        .admin-card a {
            color: white;
            text-decoration: none;
            font-weight: 500;
            font-size: 1.2rem;
            display: flex;
            align-items: center;
            gap: 10px;
            width: 100%;
        }

        .admin-card a::after {
            content: '→';
            margin-left: auto;
            opacity: 0;
            transition: var(--transition);
        }

        .admin-card:hover a::after {
            opacity: 1;
            transform: translateX(5px);
        }

        .admin-card p {
            color: rgba(255, 255, 255, 0.7);
            font-size: 0.9rem;
            margin-top: 10px;
        }

        .pulse-animation {
            animation: pulse 2s infinite;
        }

        @keyframes pulse {
            0% { box-shadow: 0 0 0 0 rgba(76, 201, 240, 0.4); }
            70% { box-shadow: 0 0 0 15px rgba(76, 201, 240, 0); }
            100% { box-shadow: 0 0 0 0 rgba(76, 201, 240, 0); }
        }

        .logout-card {
            background: rgba(247, 37, 133, 0.1);
            border-color: rgba(247, 37, 133, 0.3);
        }

        .logout-card:hover {
            background: rgba(247, 37, 133, 0.2) !important;
            border-color: var(--error) !important;
        }

        .logout-card i {
            color: var(--error);
            background: rgba(247, 37, 133, 0.1);
        }

        /* Responsive */
        @media (max-width: 768px) {
            .admin-container {
                padding: 30px 20px;
                width: 95%;
            }
            
            h2 {
                font-size: 1.8rem;
            }
            
            .admin-grid {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>
<body>
    <div class="admin-container">
        <h2>Welcome, Admin <span class="pulse-animation">👋</span></h2>
        <p>Manage your healthcare platform efficiently</p>
        
        <div class="admin-grid">
            <div class="admin-card">
                <i class="fas fa-users"></i>
                <a href="manage_users.php">Manage Users</a>
                <p>View, edit, and manage all user accounts</p>
            </div>
            
            <div class="admin-card">
                <i class="fas fa-calendar-check"></i>
                <a href="manage_appointments.php">Manage Appointments</a>
                <p>View and manage all doctor appointments</p>
            </div>
            
            <div class="admin-card">
                <i class="fas fa-pills"></i>
                <a href="manage_medicines.php">Manage Medicines</a>
                <p>Update medicine inventory and details</p>
            </div>
            
            <div class="admin-card">
                <i class="fas fa-box-open"></i>
                <a href="manage_orders.php">View Orders</a>
                <p>Track and manage all medicine orders</p>
            </div>
            
            <div class="admin-card">
                <i class="fas fa-comment-alt"></i>
                <a href="admin_feedback.php">View Feedback</a>
                <p>Read and respond to user feedback</p>
            </div>
            
            <div class="admin-card logout-card">
                <i class="fas fa-sign-out-alt"></i>
                <a href="admin_logout.php">Logout</a>
                <p>Securely exit the admin dashboard</p>
            </div>
        </div>
    </div>

    <script>
        // Add animation to cards when they come into view
        const cards = document.querySelectorAll('.admin-card');
        
        const observer = new IntersectionObserver((entries) => {
            entries.forEach((entry, index) => {
                if (entry.isIntersecting) {
                    entry.target.style.animation = fadeIn 0.5s ease-out ${index * 0.1}s forwards;
                    observer.unobserve(entry.target);
                }
            });
        }, { threshold: 0.1 });

        cards.forEach(card => {
            card.style.opacity = '0';
            observer.observe(card);
        });
    </script>
</body>
</html>