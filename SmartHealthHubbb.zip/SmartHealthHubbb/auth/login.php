<?php
require_once "../config/db.php";
require_once "../includes/functions.php";
session_start();

// Redirect if already logged in
if (isset($_SESSION['user_id'])) {
    redirect("../core/dashboard.php");
}

$error = "";
$email = "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $email = sanitizeInput($_POST['email']);
    $password = sanitizeInput($_POST['password']);

    if (!empty($email) && !empty($password)) {
        usleep(rand(200000, 500000)); // Delay to prevent timing attacks

        $stmt = $conn->prepare("SELECT id, full_name, email, password, role FROM users WHERE email = ?");
        $stmt->execute([$email]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($user && password_verify($password, $user['password'])) {
            session_regenerate_id(true); // Prevent session fixation

            $_SESSION['user_id'] = $user['id'];
            $_SESSION['user_name'] = $user['full_name'];
            $_SESSION['user_email'] = $user['email'];
            $_SESSION['user_role'] = $user['role'];
            $_SESSION['last_activity'] = time();
            $_SESSION['ip_address'] = $_SERVER['REMOTE_ADDR'];
            $_SESSION['user_agent'] = $_SERVER['HTTP_USER_AGENT'];

            // Removed last_login update since the column doesn't exist
            redirect("../core/dashboard.php");
        } else {
            $error = "❌ Invalid email or password!";
        }
    } else {
        $error = "⚠️ Please fill in both fields.";
    }
}
?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - Smart HealthHub</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary: #4361ee;
            --primary-dark: #3a0ca3;
            --primary-light: #4895ef;
            --secondary: #3f37c9;
            --accent: #4cc9f0;
            --success: #4ad66d;
            --error: #f72585;
            --warning: #f8961e;
            --light: #f8f9fa;
            --dark: #212529;
            --gray: #6c757d;
            --light-gray: #e9ecef;
            --shadow-sm: 0 1px 3px rgba(0, 0, 0, 0.1);
            --shadow-md: 0 4px 6px rgba(0, 0, 0, 0.1);
            --shadow-lg: 0 10px 15px rgba(0, 0, 0, 0.1);
            --transition: all 0.3s cubic-bezier(0.25, 0.8, 0.25, 1);
            --border-radius: 12px;
            --glass-effect: rgba(255, 255, 255, 0.15);
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
    font-family: 'Poppins', sans-serif;
    color: var(--light);
    min-height: 100vh;
    display: flex;
    justify-content: center;
    align-items: center;
    padding: 20px;
    line-height: 1.6;
    position: relative;
    overflow-x: hidden;
    
    /* Background image with gradient overlay */
    background: 
        linear-gradient(
            135deg, 
            rgba(102, 126, 234, 0.85) 0%, 
            rgba(118, 75, 162, 0.85) 100%
        ),
        url('../assets/images/background.jpg') center/cover no-repeat fixed;
    
    /* Smooth scrolling for iOS devices */
    -webkit-overflow-scrolling: touch;
    
    /* Performance optimizations */
    transform: translateZ(0);
    backface-visibility: hidden;
    perspective: 1000;
    
    /* Texture effect */
    &::before {
        content: '';
        position: absolute;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        background: 
            radial-gradient(
                circle at 20% 30%,
                rgba(255, 255, 255, 0.1) 0%,
                transparent 50%
            ),
            url('data:image/svg+xml;utf8,<svg width="100" height="100" viewBox="0 0 100 100" xmlns="http://www.w3.org/2000/svg"><path d="M0 0h100v100H0z" fill="none"/><path d="M50 50l10-20l20 10l-20 10l-10 20l-10-20l-20-10l20-10z" fill="rgba(255,255,255,0.03)" /></svg>');
        background-size: 100%, 150px 150px;
        opacity: 0.5;
        z-index: -1;
    }
    
    /* Animated floating particles */
    &::after {
        content: '';
        position: absolute;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        background: 
            url('data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 200 200"><circle cx="20" cy="20" r="1.5" fill="rgba(255,255,255,0.3)"/><circle cx="80" cy="60" r="1" fill="rgba(255,255,255,0.2)"/><circle cx="150" cy="30" r="2" fill="rgba(255,255,255,0.25)"/><circle cx="40" cy="120" r="1.5" fill="rgba(255,255,255,0.3)"/><circle cx="120" cy="150" r="1" fill="rgba(255,255,255,0.2)"/><circle cx="180" cy="100" r="2" fill="rgba(255,255,255,0.25)"/></svg>');
        background-size: 200px 200px;
        animation: floatParticles 60s linear infinite;
        z-index: -1;
        pointer-events: none;
    }
}

@keyframes floatParticles {
    0% {
        background-position: 0% 0%;
    }
    100% {
        background-position: 100% 100%;
    }
}

        .login-container {
            width: 100%;
            max-width: 850px;
            background: rgba(255, 255, 255, 0.3);
            border-radius: var(--border-radius);
            box-shadow: var(--shadow-lg);
            overflow: hidden;
            animation: fadeIn 0.6s ease-out;
            position: relative;
            z-index: 1;
            backdrop-filter: blur(5px);
            border: 1px solid var(--glass-effect);
        }

        .login-container::before {
            content: '';
            position: absolute;
            top: -50%;
            left: -50%;
            width: 200%;
            height: 200%;
            background: linear-gradient(
                to bottom right,
                rgba(255, 255, 255, 0.1),
                rgba(255, 255, 255, 0)
            );
            transform: rotate(30deg);
            z-index: -1;
        }

        .login-header {
            padding: 40px 40px 20px;
            text-align: center;
            position: relative;
        }

        .logo-container {
            display: flex;
            justify-content: center;
            margin-bottom: 20px;
            position: relative;
        }

        .logo {
            width: 100px;
            height: 100px;
            border-radius: 50%;
            object-fit: cover;
            border: 3px solid white;
            box-shadow: 0 8px 20px rgba(0, 0, 0, 0.15);
            transition: var(--transition);
            background: linear-gradient(135deg, var(--primary), var(--secondary));
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 36px;
            font-weight: bold;
            text-transform: uppercase;
        }

        .logo:hover {
            transform: scale(1.05) rotate(5deg);
            box-shadow: 0 12px 25px rgba(0, 0, 0, 0.2);
        }

        h2 {
            color: var(--dark);
            margin-bottom: 10px;
            font-weight: 700;
            font-size: 28px;
            background: linear-gradient(to right, var(--primary), var(--secondary));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }

        .login-subtitle {
            color: var(--gray);
            font-size: 14px;
            margin-bottom: 30px;
        }

        .login-body {
            padding: 0 40px 40px;
        }

        .error-message {
            background-color: rgba(247, 37, 133, 0.1);
            color: var(--error);
            padding: 12px 15px;
            border-radius: var(--border-radius);
            margin-bottom: 25px;
            display: flex;
            align-items: center;
            gap: 10px;
            border-left: 4px solid var(--error);
            animation: shake 0.5s ease;
        }

        @keyframes shake {
            0%, 100% { transform: translateX(0); }
            20%, 60% { transform: translateX(-5px); }
            40%, 80% { transform: translateX(5px); }
        }

        .login-form {
            display: flex;
            flex-direction: column;
            gap: 20px;
        }

        .input-group {
            position: relative;
        }

        .input-group label {
            display: block;
            margin-bottom: 8px;
            color: var(--dark);
            font-weight: 500;
            font-size: 14px;
        }

        .input-group input {
            width: 100%;
            padding: 14px 15px 14px 45px;
            border: 1px solid var(--light-gray);
            border-radius: var(--border-radius);
            font-size: 15px;
            transition: var(--transition);
            background-color: rgba(255, 255, 255, 0.8);
        }

        .input-group input:focus {
            border-color: var(--primary-light);
            outline: none;
            box-shadow: 0 0 0 3px rgba(67, 97, 238, 0.2);
            background-color: white;
        }

        .input-icon {
            position: absolute;
            left: 15px;
            top: 40px;
            color: var(--primary);
            transition: var(--transition);
        }

        .input-group input:focus + .input-icon {
            color: var(--primary-light);
        }

        .password-toggle {
            position: absolute;
            right: 15px;
            top: 40px;
            cursor: pointer;
            color: var(--gray);
            transition: var(--transition);
        }

        .password-toggle:hover {
            color: var(--primary);
        }

        .btn-login {
            background: linear-gradient(to right, var(--primary), var(--secondary));
            color: white;
            border: none;
            padding: 15px;
            border-radius: var(--border-radius);
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            transition: var(--transition);
            margin-top: 10px;
            box-shadow: 0 4px 10px rgba(67, 97, 238, 0.3);
            position: relative;
            overflow: hidden;
        }

        .btn-login:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 15px rgba(67, 97, 238, 0.4);
        }

        .btn-login:active {
            transform: translateY(0);
        }

        .btn-login::after {
            content: '';
            position: absolute;
            top: -50%;
            left: -50%;
            width: 200%;
            height: 200%;
            background: linear-gradient(
                to bottom right,
                rgba(255, 255, 255, 0.3),
                rgba(255, 255, 255, 0)
            );
            transform: rotate(30deg);
            transition: var(--transition);
            opacity: 0;
        }

        .btn-login:hover::after {
            opacity: 1;
        }

        .links {
            margin-top: 25px;
            display: flex;
            flex-direction: column;
            gap: 15px;
            text-align: center;
        }

        .links a {
            color: var(--primary);
            text-decoration: none;
            font-size: 14px;
            transition: var(--transition);
            display: inline-flex;
            align-items: center;
            gap: 5px;
        }

        .links a:hover {
            color: var(--secondary);
            text-decoration: underline;
        }

        .divider {
            display: flex;
            align-items: center;
            margin: 20px 0;
            color: var(--gray);
            font-size: 12px;
            text-transform: uppercase;
        }

        .divider::before, .divider::after {
            content: "";
            flex: 1;
            border-bottom: 1px solid var(--light-gray);
        }

        .divider::before {
            margin-right: 10px;
        }

        .divider::after {
            margin-left: 10px;
        }

        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }

        @media (max-width: 576px) {
            .login-container {
                padding: 30px 20px;
            }
            
            .login-header, .login-body {
                padding: 20px;
            }
        }
    </style>
</head>
<body>
    <div class="login-container">
        <div class="login-header">
            <div class="logo-container">
                <div class="logo"><img src="../assets/images/logo.jpeg"   class="logo">
                </div>
            </div>
            <h2>Welcome Back</h2>
            <p class="login-subtitle">Please login to access your health dashboard</p>
        </div>

        <div class="login-body">
            <?php if ($error): ?>
                <div class="error-message">
                    <i class="fas fa-exclamation-circle"></i>
                    <?php echo htmlspecialchars($error, ENT_QUOTES, 'UTF-8'); ?>
                </div>
            <?php endif; ?>

            <form method="POST" class="login-form" autocomplete="on">
                <div class="input-group">
                    <label for="email">Email Address</label>
                    <input type="email" id="email" name="email" placeholder="Enter your email" required value="<?php echo htmlspecialchars($email, ENT_QUOTES, 'UTF-8'); ?>">
                    <i class="fas fa-envelope input-icon"></i>
                </div>

                <div class="input-group">
                    <label for="password">Password</label>
                    <input type="password" id="password" name="password" placeholder="Enter your password" required>
                    <i class="fas fa-lock input-icon"></i>
                    <span class="password-toggle" onclick="togglePassword()">
                        <i class="fas fa-eye"></i>
                    </span>
                </div>

                <button type="submit" class="btn-login">
                    <i class="fas fa-sign-in-alt"></i> Login
                </button>
            </form>

            <div class="links">
                <a href="forgot-password.php"><i class="fas fa-key"></i> Forgot Password?</a>
                <div class="divider">OR</div>
                <a href="signup.php"><i class="fas fa-user-plus"></i> Create New Account</a>
            </div>
        </div>
    </div>

    <script>
        function togglePassword() {
            const passwordInput = document.getElementById('password');
            const toggleIcon = document.querySelector('.password-toggle i');
            
            if (passwordInput.type === 'password') {
                passwordInput.type = 'text';
                toggleIcon.classList.replace('fa-eye', 'fa-eye-slash');
            } else {
                passwordInput.type = 'password';
                toggleIcon.classList.replace('fa-eye-slash', 'fa-eye');
            }
        }

        // Add animation to input fields on focus
        document.querySelectorAll('.input-group input').forEach(input => {
            input.addEventListener('focus', function() {
                this.parentNode.querySelector('.input-icon').style.color = '#4cc9f0';
            });
            
            input.addEventListener('blur', function() {
                this.parentNode.querySelector('.input-icon').style.color = '#4361ee';
            });
        });
    </script>
</body>
</html>